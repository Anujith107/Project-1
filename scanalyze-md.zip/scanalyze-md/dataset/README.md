# Medical Imaging Datasets Guide: ScanalyzeMD

ScanalyzeMD is designed to work with de-identified, publicly available medical imaging research datasets for Chest X-Ray, CT, and MRI modalities.

> [!NOTE]
> All medical data used in this project must be completely de-identified and compliant with HIPAA/GDPR health data privacy regulations. Do not include Protected Health Information (PHI).

---

## 1. Supported Modalities & Public Benchmark Datasets

### A. Chest Radiography (X-Ray)
- **NIH ChestX-ray14**: 112,120 frontal chest radiographs with 14 disease labels (Pneumonia, Infiltration, Atelectasis, Effusion, etc.).
  - *Source*: [NIH Clinical Center Chest X-Ray Dataset](https://nihcc.app.box.com/v/ChestXray-NIHCC)
- **CheXpert**: 224,316 chest radiographs from Stanford Hospital.
  - *Source*: [Stanford AIMI CheXpert](https://aimi.stanford.edu/chexpert-chest-x-rays)
- **COVID-19 Radiography Database**: Curated normal, viral pneumonia, and opacity cases.
  - *Source*: [Kaggle COVID-19 Radiography Database](https://www.kaggle.com/datasets/tawsifurrahman/covid19-radiography-database)

### B. Computed Tomography (CT)
- **CQ500 Dataset**: 491 non-contrast head CT studies (over 200,000 slices) labeled for acute intracranial hemorrhage, skull fractures, and midline shifts.
  - *Source*: [Centre for Advanced Medical Imaging CQ500](http://headctstudy.qure.ai/dataset)
- **RSNA Intracranial Hemorrhage Detection**: Multi-class acute hemorrhage CT dataset.
  - *Source*: [RSNA Intracranial Hemorrhage CT Challenge](https://www.kaggle.com/c/rsna-intracranial-hemorrhage-detection)

### C. Magnetic Resonance Imaging (MRI)
- **BraTS (Brain Tumor Segmentation) Challenge**: Multi-parametric brain MRI scans (T1, T1Gd, T2, FLAIR) with gliomas and hyperintense parenchymal lesions.
  - *Source*: [Brain Tumor Segmentation Benchmark](https://www.med.upenn.edu/cbica/brats/)
- **OASIS Brains**: Open Access Series of Imaging Studies (structural MRI of normal aging and neurodegenerative conditions).
  - *Source*: [OASIS-Brains.org](https://www.oasis-brains.org/)

---

## 2. Expected Dataset Directory Structure for Training

To train the models using the provided training scripts, organize your dataset into the following directory format:

```text
dataset/
├── xray/
│   ├── class_0_normal/
│   │   ├── normal_001.png
│   │   └── normal_002.png
│   ├── class_1_opacity/
│   │   ├── opacity_001.png
│   │   └── opacity_002.png
│   └── class_2_other/
│       ├── other_001.png
│       └── ...
│
├── ct/
│   ├── class_0_normal/
│   │   ├── ct_norm_001.png
│   │   └── ...
│   └── class_1_acute_lesion/
│       ├── ct_bleed_001.png
│       └── ...
│
└── mri/
    ├── class_0_normal/
    │   ├── mri_norm_001.png
    │   └── ...
    └── class_1_hyperintense_lesion/
        ├── mri_lesion_001.png
        └── ...
```

---

## 3. Training Commands

Run the respective training script:

```bash
# Train Chest X-Ray Model
python backend/training/train_xray.py --data_dir dataset/xray --epochs 15 --batch_size 16 --lr 1e-4

# Train CT Model
python backend/training/train_ct.py --data_dir dataset/ct --epochs 15 --batch_size 16 --lr 1e-4

# Train MRI Model
python backend/training/train_mri.py --data_dir dataset/mri --epochs 15 --batch_size 16 --lr 1e-4
```

Checkpoints will automatically save to:
- `models/xray/model.pt`
- `models/ct/model.pt`
- `models/mri/model.pt`
