import os
import sys
from pathlib import Path
import numpy as np
import cv2
from PIL import Image
import torch
import pydicom
from pydicom.dataset import Dataset, FileDataset, FileMetaDataset
from pydicom.uid import ExplicitVRLittleEndian, SecondaryCaptureImageStorage, generate_uid
import datetime

# Root paths
BACKEND_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BACKEND_DIR.parent
sys.path.insert(0, str(PROJECT_ROOT))
from backend.app.config import SAMPLE_DATA_DIR, MODELS_DIR
from backend.app.inference.xray_model import XRayResNet18
from backend.app.inference.ct_model import CTResNet18
from backend.app.inference.mri_model import MRIResNet18
from backend.app.inference.model_loader import save_model_weights

SAMPLE_DIR = SAMPLE_DATA_DIR

def save_as_dicom(
    pixel_array: np.ndarray,
    output_path: Path,
    modality: str,
    patient_id: str,
    patient_name: str,
    study_desc: str,
    view_pos: str = "PA"
):
    """Encodes a 2D uint8 numpy array into a valid DICOM file with full medical metadata."""
    file_meta = FileMetaDataset()
    file_meta.MediaStorageSOPClassUID = SecondaryCaptureImageStorage
    file_meta.MediaStorageSOPInstanceUID = generate_uid()
    file_meta.TransferSyntaxUID = ExplicitVRLittleEndian
    file_meta.ImplementationClassUID = generate_uid()

    ds = FileDataset(str(output_path), {}, file_meta=file_meta, preamble=b"\0" * 128)
    ds.Modality = modality
    ds.PatientID = patient_id
    ds.PatientName = patient_name
    ds.StudyDescription = study_desc
    ds.SeriesDescription = f"{modality} Series - {study_desc}"
    ds.ViewPosition = view_pos
    ds.PatientSex = "O"
    ds.PatientAge = "045Y"
    ds.StudyDate = datetime.date.today().strftime("%Y%m%d")
    ds.StudyTime = datetime.datetime.now().strftime("%H%M%S")
    ds.SOPClassUID = SecondaryCaptureImageStorage
    ds.SOPInstanceUID = file_meta.MediaStorageSOPInstanceUID

    ds.Rows, ds.Columns = pixel_array.shape[:2]
    ds.SamplesPerPixel = 1
    ds.PhotometricInterpretation = "MONOCHROME2"
    ds.PixelRepresentation = 0
    ds.HighBit = 7
    ds.BitsStored = 8
    ds.BitsAllocated = 8
    ds.RescaleIntercept = "0"
    ds.RescaleSlope = "1"

    if pixel_array.ndim == 3:
        gray = cv2.cvtColor(pixel_array, cv2.COLOR_RGB2GRAY)
    else:
        gray = pixel_array

    ds.PixelData = gray.astype(np.uint8).tobytes()
    ds.is_little_endian = True
    ds.is_implicit_VR = False
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(str(output_path), "wb") as fp:
        pydicom.dcmwrite(fp, ds, write_like_original=False)

def create_chest_xray_pattern(abnormal: bool = False) -> np.ndarray:
    """Generates an anatomically structured synthetic frontal chest radiograph."""
    h, w = 512, 512
    img = np.zeros((h, w), dtype=np.float32)

    # Thoracic cage background
    y, x = np.ogrid[:h, :w]
    chest_outline = np.exp(-(((x - 256)/180)**2 + ((y - 270)/220)**2))
    img += chest_outline * 160.0

    # Bilateral Lung Fields (low density / dark)
    left_lung = np.exp(-(((x - 170)/60)**2 + ((y - 250)/120)**2))
    right_lung = np.exp(-(((x - 342)/60)**2 + ((y - 250)/120)**2))
    lung_mask = left_lung + right_lung
    img -= lung_mask * 110.0

    # Mediastinum and Cardiac Silhouette (dense / bright, shifted slightly left)
    heart = np.exp(-(((x - 280)/65)**2 + ((y - 300)/75)**2))
    spine_sternum = np.exp(-(((x - 256)/22)**2 + ((y - 260)/240)**2))
    img += heart * 90.0
    img += spine_sternum * 60.0

    # Rib cage horizontal arcs
    for i in range(7):
        ry = 150 + i * 40
        rib = np.exp(-((y - ry - 0.05*(x - 256)**2/10)/8)**2) * 20.0
        img += rib

    # Clavicles
    clav_l = np.exp(-((y - 120 + 0.15*(x - 170))**2)/12) * 35.0 * (x < 250)
    clav_r = np.exp(-((y - 120 - 0.15*(x - 342))**2)/12) * 35.0 * (x > 262)
    img += clav_l + clav_r

    # Add abnormality: Consolidation / opacity in right lower lung zone
    if abnormal:
        opacity = np.exp(-(((x - 330)/42)**2 + ((y - 310)/48)**2)) * 130.0
        opacity += np.exp(-(((x - 350)/30)**2 + ((y - 280)/35)**2)) * 90.0
        img += opacity

    # Add realistic subtle Poisson/Gaussian sensor noise
    noise = np.random.normal(0, 3.5, (h, w))
    img = np.clip(img + noise, 0, 255).astype(np.uint8)
    return img

def create_ct_slice_pattern(abnormal: bool = False) -> np.ndarray:
    """Generates an anatomically structured synthetic axial CT brain slice."""
    h, w = 512, 512
    img = np.zeros((h, w), dtype=np.float32)
    y, x = np.ogrid[:h, :w]

    # Calvarium (Skull bone - very dense / high HU)
    dist_center = np.sqrt((x - 256)**2 + (y - 256)**2)
    skull_outer = dist_center < 195
    skull_inner = dist_center < 182
    skull_bone = skull_outer & ~skull_inner
    img[skull_bone] = 240.0

    # Brain Parenchyma (Soft tissue gray/white matter)
    brain = dist_center <= 182
    img[brain] = 95.0

    # Cerebral Ventricles (CSF - darker fluid density)
    vent_l = np.exp(-(((x - 235)/15)**2 + ((y - 256)/50)**2)) * 60.0
    vent_r = np.exp(-(((x - 277)/15)**2 + ((y - 256)/50)**2)) * 60.0
    img -= (vent_l + vent_r) * brain

    # Cortical sulci
    for ang in np.linspace(0, 2*np.pi, 28, endpoint=False):
        sx = 256 + 175 * np.cos(ang)
        sy = 256 + 175 * np.sin(ang)
        sulc = np.exp(-(((x - sx)/8)**2 + ((y - sy)/8)**2)) * 40.0
        img -= sulc * brain

    # Abnormality: Hyperdense acute intracerebral hemorrhage with surrounding hypodense edema
    if abnormal:
        hemorrhage = np.exp(-(((x - 300)/24)**2 + ((y - 225)/26)**2)) * 145.0
        edema_ring = np.exp(-(((x - 300)/45)**2 + ((y - 225)/48)**2)) * 30.0
        img -= edema_ring * brain
        img += hemorrhage * brain

    noise = np.random.normal(0, 2.5, (h, w))
    img = np.clip(img + noise, 0, 255).astype(np.uint8)
    return img

def create_mri_slice_pattern(abnormal: bool = False) -> np.ndarray:
    """Generates an anatomically structured synthetic T2-weighted axial brain MRI slice."""
    h, w = 512, 512
    img = np.zeros((h, w), dtype=np.float32)
    y, x = np.ogrid[:h, :w]

    dist_center = np.sqrt(((x - 256)/180)**2 + ((y - 256)/205)**2)
    scalp = (dist_center < 1.05) & (dist_center >= 0.96)
    img[scalp] = 110.0

    brain_mask = dist_center < 0.95
    # Gray / White matter differential signal
    parenchyma = np.sin(x/14.0) * np.cos(y/18.0) * 8.0 + 85.0
    img[brain_mask] = parenchyma[brain_mask]

    # Ventricles (Bright fluid on T2)
    vent_l = np.exp(-(((x - 238)/18)**2 + ((y - 250)/55)**2)) * 110.0
    vent_r = np.exp(-(((x - 274)/18)**2 + ((y - 250)/55)**2)) * 110.0
    img += (vent_l + vent_r) * brain_mask

    # Abnormality: Hyperintense mass with mass effect
    if abnormal:
        tumor_core = np.exp(-(((x - 210)/28)**2 + ((y - 290)/32)**2)) * 135.0
        peritumoral_edema = np.exp(-(((x - 210)/55)**2 + ((y - 290)/58)**2)) * 55.0
        img += (tumor_core + peritumoral_edema) * brain_mask

    noise = np.random.normal(0, 2.0, (h, w))
    img = np.clip(img + noise, 0, 255).astype(np.uint8)
    return img

def create_lateral_xray_pattern() -> np.ndarray:
    """Generates a lateral projection radiograph (used to test orientation validation failure)."""
    h, w = 512, 512
    img = np.zeros((h, w), dtype=np.float32)
    y, x = np.ogrid[:h, :w]
    
    # Highly asymmetric lateral chest silhouette
    lateral_body = np.exp(-(((x - 200)/140)**2 + ((y - 260)/200)**2)) * 160.0
    img += lateral_body
    
    # Spine along posterior edge (left side)
    spine = np.exp(-(((x - 120)/20)**2 + ((y - 260)/220)**2)) * 80.0
    img += spine
    
    # Sternum along anterior edge (right side)
    sternum = np.exp(-(((x - 310)/15)**2 + ((y - 230)/100)**2)) * 60.0
    img += sternum

    noise = np.random.normal(0, 3.0, (h, w))
    return np.clip(img + noise, 0, 255).astype(np.uint8)

def main():
    SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    MODELS_DIR.mkdir(parents=True, exist_ok=True)

    print("Generating high-resolution sample scans and DICOM datasets...")

    # 1. Chest X-Ray Normal
    xray_norm = create_chest_xray_pattern(abnormal=False)
    cv2.imwrite(str(SAMPLE_DIR / "xray_normal.png"), xray_norm)
    save_as_dicom(xray_norm, SAMPLE_DIR / "xray_normal.dcm", "CR", "PT-XRAY-001", "ANON^NORMAL", "Chest PA", "PA")

    # 2. Chest X-Ray Opacity / Pneumonia
    xray_abn = create_chest_xray_pattern(abnormal=True)
    cv2.imwrite(str(SAMPLE_DIR / "xray_opacity.png"), xray_abn)
    save_as_dicom(xray_abn, SAMPLE_DIR / "xray_opacity.dcm", "CR", "PT-XRAY-002", "ANON^PNEUMONIA", "Chest PA Focal Opacity", "PA")

    # 3. CT Normal
    ct_norm = create_ct_slice_pattern(abnormal=False)
    cv2.imwrite(str(SAMPLE_DIR / "ct_normal.png"), ct_norm)
    save_as_dicom(ct_norm, SAMPLE_DIR / "ct_normal.dcm", "CT", "PT-CT-001", "ANON^HEAD_NORMAL", "Brain CT Axial Non-Contrast")

    # 4. CT Hemorrhage / Acute Lesion
    ct_abn = create_ct_slice_pattern(abnormal=True)
    cv2.imwrite(str(SAMPLE_DIR / "ct_hemorrhage.png"), ct_abn)
    save_as_dicom(ct_abn, SAMPLE_DIR / "ct_hemorrhage.dcm", "CT", "PT-CT-002", "ANON^HEAD_BLEED", "Brain CT Acute Hemorrhage")

    # 5. MRI Normal
    mri_norm = create_mri_slice_pattern(abnormal=False)
    cv2.imwrite(str(SAMPLE_DIR / "mri_normal.png"), mri_norm)
    save_as_dicom(mri_norm, SAMPLE_DIR / "mri_normal.dcm", "MR", "PT-MRI-001", "ANON^BRAIN_NORMAL", "Brain MRI T2 Axial")

    # 6. MRI Lesion / Tumor
    mri_abn = create_mri_slice_pattern(abnormal=True)
    cv2.imwrite(str(SAMPLE_DIR / "mri_tumor.png"), mri_abn)
    save_as_dicom(mri_abn, SAMPLE_DIR / "mri_tumor.dcm", "MR", "PT-MRI-002", "ANON^BRAIN_LESION", "Brain MRI T2 Hyperintensity")

    # 7. Invalid test case: Lateral X-Ray
    lat_xray = create_lateral_xray_pattern()
    cv2.imwrite(str(SAMPLE_DIR / "xray_lateral_invalid.png"), lat_xray)
    save_as_dicom(lat_xray, SAMPLE_DIR / "xray_lateral_invalid.dcm", "CR", "PT-LAT-001", "ANON^LATERAL", "Chest Lateral View", "LL")

    # 8. Invalid test case: Blurry / low quality
    blurry = cv2.GaussianBlur(xray_norm, (35, 35), 0)
    cv2.imwrite(str(SAMPLE_DIR / "blurry_invalid.png"), blurry)

    print("Sample scan files created successfully in sample_data/")

    # Initialize model weights for each modality
    print("Initializing PyTorch models and saving initial weights...")
    xray_model = XRayResNet18(num_classes=3, pretrained=True)
    ct_model = CTResNet18(num_classes=2, pretrained=True)
    mri_model = MRIResNet18(num_classes=2, pretrained=True)

    save_model_weights(xray_model, "xray")
    save_model_weights(ct_model, "ct")
    save_model_weights(mri_model, "mri")
    print("Initial model checkpoints saved in models/xray, models/ct, models/mri.")

if __name__ == "__main__":
    main()
