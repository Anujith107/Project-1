import numpy as np
import cv2
from PIL import Image
import pydicom
import torch
import torchvision.transforms as transforms
from typing import Tuple, Dict, Any, Union
from pathlib import Path

# Standard ImageNet normalization for torchvision pretrained backbones
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]

def read_scan_file(file_path: Union[str, Path]) -> Tuple[np.ndarray, Dict[str, Any]]:
    """
    Reads an uploaded file (DICOM or standard image) into a numpy array (H, W, 3) in uint8 format [0, 255]
    and extracts DICOM metadata if present.
    """
    path = Path(file_path)
    ext = path.suffix.lower()
    meta = {}

    if ext in {".dcm", ".dicom"}:
        dcm = pydicom.dcmread(str(path), force=True)
        pixel_array = dcm.pixel_array.astype(np.float32)

        # Apply RescaleSlope and RescaleIntercept if present
        slope = getattr(dcm, "RescaleSlope", 1.0)
        intercept = getattr(dcm, "RescaleIntercept", 0.0)
        pixel_array = pixel_array * float(slope) + float(intercept)

        # Photometric Interpretation check
        photometric = getattr(dcm, "PhotometricInterpretation", "MONOCHROME2")
        if photometric == "MONOCHROME1":
            pixel_array = np.max(pixel_array) - pixel_array

        # Normalize to 0-255 uint8
        p_min = np.min(pixel_array)
        p_max = np.max(pixel_array)
        if p_max > p_min:
            norm_array = ((pixel_array - p_min) / (p_max - p_min) * 255.0).astype(np.uint8)
        else:
            norm_array = np.zeros_like(pixel_array, dtype=np.uint8)

        # Convert to 3-channel RGB
        if norm_array.ndim == 2:
            rgb_array = cv2.cvtColor(norm_array, cv2.COLOR_GRAY2RGB)
        else:
            rgb_array = norm_array

        meta = {
            "Modality": getattr(dcm, "Modality", "UNKNOWN"),
            "PatientID": getattr(dcm, "PatientID", "ANONYMOUS"),
            "StudyDescription": getattr(dcm, "StudyDescription", ""),
            "SeriesDescription": getattr(dcm, "SeriesDescription", ""),
            "ViewPosition": getattr(dcm, "ViewPosition", ""),
            "PhotometricInterpretation": str(photometric),
            "Rows": int(getattr(dcm, "Rows", norm_array.shape[0])),
            "Columns": int(getattr(dcm, "Columns", norm_array.shape[1]))
        }
        return rgb_array, meta

    else:
        # Standard image (PNG/JPG)
        pil_img = Image.open(path).convert("RGB")
        rgb_array = np.array(pil_img, dtype=np.uint8)
        meta = {
            "Format": pil_img.format or "PNG",
            "Dimensions": list(pil_img.size)
        }
        return rgb_array, meta

def apply_clahe(image_rgb: np.ndarray, clip_limit: float = 2.0, tile_grid_size: Tuple[int, int] = (8, 8)) -> np.ndarray:
    """
    Applies Contrast Limited Adaptive Histogram Equalization on the luminance channel.
    """
    lab = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2LAB)
    l_chan, a_chan, b_chan = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid_size)
    cl = clahe.apply(l_chan)
    merged = cv2.merge((cl, a_chan, b_chan))
    return cv2.cvtColor(merged, cv2.COLOR_LAB2RGB)

def to_tensor_normalized(image_rgb: np.ndarray, target_size: Tuple[int, int] = (224, 224)) -> torch.Tensor:
    """
    Resizes and converts uint8 [H, W, 3] numpy array to PyTorch Tensor [1, 3, target_h, target_w]
    normalized with ImageNet mean and std.
    """
    resized = cv2.resize(image_rgb, target_size, interpolation=cv2.INTER_AREA)
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD)
    ])
    tensor = transform(resized).unsqueeze(0)  # Add batch dimension [1, 3, H, W]
    return tensor
