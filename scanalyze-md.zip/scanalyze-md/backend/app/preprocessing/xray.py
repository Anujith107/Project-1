import numpy as np
import cv2
import torch
from typing import Tuple
from backend.app.preprocessing.common import apply_clahe, to_tensor_normalized

def preprocess_xray(image_rgb: np.ndarray, target_size: Tuple[int, int] = (224, 224)) -> Tuple[torch.Tensor, np.ndarray]:
    """
    Modality-specific preprocessing pipeline for Chest X-Ray:
    1. Grayscale luminance extraction
    2. Adaptive contrast enhancement (CLAHE) tailored for lung parenchyma and ribs
    3. Resizing and ImageNet tensor normalization
    Returns (normalized_tensor, preprocessed_display_rgb).
    """
    # Apply CLAHE with optimized clip limit for thoracic bone and lung field separation
    enhanced_rgb = apply_clahe(image_rgb, clip_limit=2.5, tile_grid_size=(8, 8))
    tensor = to_tensor_normalized(enhanced_rgb, target_size=target_size)
    return tensor, enhanced_rgb
