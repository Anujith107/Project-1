import numpy as np
import cv2
import torch
from typing import Tuple
from backend.app.preprocessing.common import apply_clahe, to_tensor_normalized

def preprocess_ct(image_rgb: np.ndarray, target_size: Tuple[int, int] = (224, 224)) -> Tuple[torch.Tensor, np.ndarray]:
    """
    Modality-specific preprocessing pipeline for CT scans:
    1. Tissue window dynamic range emphasis (gamma correction / soft tissue contrast)
    2. Sub-pixel bilateral edge preservation filtering
    3. Resizing and ImageNet tensor normalization
    Returns (normalized_tensor, preprocessed_display_rgb).
    """
    # Soft tissue windowing simulation via subtle gamma adjustment (gamma=1.1)
    gamma = 1.1
    inv_gamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
    adjusted_rgb = cv2.LUT(image_rgb, table)

    # Mild bilateral filtering to preserve edges while smoothing scanner noise
    filtered_rgb = cv2.bilateralFilter(adjusted_rgb, d=5, sigmaColor=35, sigmaSpace=35)
    
    tensor = to_tensor_normalized(filtered_rgb, target_size=target_size)
    return tensor, filtered_rgb
