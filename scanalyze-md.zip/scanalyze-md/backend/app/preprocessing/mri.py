import numpy as np
import cv2
import torch
from typing import Tuple
from backend.app.preprocessing.common import to_tensor_normalized

def preprocess_mri(image_rgb: np.ndarray, target_size: Tuple[int, int] = (224, 224)) -> Tuple[torch.Tensor, np.ndarray]:
    """
    Modality-specific preprocessing pipeline for MRI scans:
    1. Grayscale normalization and signal intensity standardization
    2. Non-local tissue contrast calibration
    3. Resizing and ImageNet tensor normalization
    Returns (normalized_tensor, preprocessed_display_rgb).
    """
    # MRI signal intensity rescaling (z-score like normalization between 1st and 99th percentile)
    gray = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2GRAY).astype(np.float32)
    non_zero = gray[gray > 5]
    
    if len(non_zero) > 10:
        p1 = np.percentile(non_zero, 1)
        p99 = np.percentile(non_zero, 99)
        clipped = np.clip(gray, p1, p99)
        if p99 > p1:
            norm = ((clipped - p1) / (p99 - p1) * 255.0).astype(np.uint8)
        else:
            norm = gray.astype(np.uint8)
    else:
        norm = gray.astype(np.uint8)

    enhanced_rgb = cv2.cvtColor(norm, cv2.COLOR_GRAY2RGB)
    tensor = to_tensor_normalized(enhanced_rgb, target_size=target_size)
    return tensor, enhanced_rgb
