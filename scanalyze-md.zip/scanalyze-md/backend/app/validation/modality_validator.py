import numpy as np
import cv2
from typing import Dict, Any, Optional

MODALITY_MAPPING = {
    "xray": ["CR", "DX", "RG", "X-RAY", "CHEST X-RAY", "XRAY"],
    "ct": ["CT", "CAT"],
    "mri": ["MR", "MRI", "MAGNETIC RESONANCE"]
}

def validate_modality_compatibility(
    selected_modality: str,
    image_array: np.ndarray,
    dicom_meta: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Validates selected modality against DICOM metadata and pixel characteristics.
    """
    selected_mod = selected_modality.lower().strip()
    if selected_mod not in {"xray", "ct", "mri"}:
        return {
            "valid": False,
            "status": "INVALID",
            "reason": f"Unknown modality selection: '{selected_modality}'. Supported: X-Ray, CT, MRI.",
            "detected_modality": None
        }

    detected_modality = None

    # Check DICOM tag if present
    if dicom_meta and "Modality" in dicom_meta:
        dicom_tag = str(dicom_meta["Modality"]).upper()
        if dicom_tag in {"CR", "DX", "RG"}:
            detected_modality = "xray"
        elif dicom_tag == "CT":
            detected_modality = "ct"
        elif dicom_tag == "MR":
            detected_modality = "mri"

        if detected_modality and detected_modality != selected_mod:
            return {
                "valid": False,
                "status": "INVALID",
                "reason": f"Selected modality '{selected_mod.upper()}' does not match DICOM header modality '{dicom_tag}' (Detected: {detected_modality.upper()}).",
                "detected_modality": detected_modality
            }

    # Image-based heuristic checks (for PNG/JPG inputs)
    if image_array.ndim == 3 and image_array.shape[2] >= 3:
        # Check if color channels differ significantly (real medical scans are typically grayscale)
        r, g, b = image_array[:, :, 0], image_array[:, :, 1], image_array[:, :, 2]
        color_diff = np.mean(np.abs(r.astype(float) - g.astype(float))) + np.mean(np.abs(g.astype(float) - b.astype(float)))
        if color_diff > 35.0:
            return {
                "valid": True,
                "status": "WARNING",
                "reason": "Non-grayscale/colorized scan input detected. Converted to single-channel luminosity for analysis.",
                "detected_modality": selected_mod
            }

    modality_labels = {
        "xray": "Chest X-Ray",
        "ct": "Computed Tomography (CT)",
        "mri": "Magnetic Resonance Imaging (MRI)"
    }

    return {
        "valid": True,
        "status": "VALID",
        "reason": f"Scan is compatible with {modality_labels.get(selected_mod, selected_mod.upper())} pipeline.",
        "detected_modality": detected_modality or selected_mod
    }
