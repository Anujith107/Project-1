import numpy as np
import cv2
from typing import Dict, Any, Optional

def validate_scan_orientation(
    image_array: np.ndarray,
    modality_key: str,
    dicom_meta: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Validates scan positioning, aspect ratio, symmetry, and projection view.
    - For Chest X-Ray: Validates frontal PA/AP projection vs lateral view or severe tilt/rotation.
    - For CT / MRI: Validates standard axial/coronal slice aspect ratio and anatomical centering.
    """
    if image_array.ndim == 3:
        if image_array.shape[2] >= 3:
            gray = cv2.cvtColor(image_array[:, :, :3], cv2.COLOR_RGB2GRAY)
        else:
            gray = image_array[:, :, 0]
    else:
        gray = image_array

    if gray.dtype != np.uint8:
        norm = cv2.normalize(gray, None, 0, 255, cv2.NORM_MINMAX)
        gray = norm.astype(np.uint8)

    height, width = gray.shape[:2]
    aspect_ratio = width / max(height, 1)

    # Check DICOM view position if available
    if dicom_meta:
        view_position = str(dicom_meta.get("ViewPosition", "")).upper()
        series_desc = str(dicom_meta.get("SeriesDescription", "")).upper()
        if "LATERAL" in view_position or "LAT" in series_desc:
            return {
                "valid": False,
                "status": "INVALID",
                "reason": "Lateral view detected. Only frontal PA/AP projections are supported.",
                "details": {"view_position": view_position, "aspect_ratio": round(aspect_ratio, 2)}
            }

    if modality_key == "xray":
        # Extreme aspect ratio check (chest x-rays are roughly 0.75 - 1.35)
        if aspect_ratio < 0.5 or aspect_ratio > 2.0:
            return {
                "valid": False,
                "status": "INVALID",
                "reason": f"Abnormal aspect ratio ({aspect_ratio:.2f}) for frontal chest radiograph.",
                "details": {"aspect_ratio": round(aspect_ratio, 2), "dimensions": [width, height]}
            }

        # Bilateral thoracic symmetry analysis (compare left and right hemithorax density)
        mid_x = width // 2
        left_half = gray[:, :mid_x]
        right_half = cv2.flip(gray[:, mid_x:], 1)
        
        # Resize to match width if odd
        min_w = min(left_half.shape[1], right_half.shape[1])
        left_crop = left_half[:, :min_w]
        right_crop = right_half[:, :min_w]

        # Calculate mean intensities of left and right quadrants
        left_mean = float(np.mean(left_crop))
        right_mean = float(np.mean(right_crop))
        denom = max(left_mean + right_mean, 1.0)
        asymmetry_index = abs(left_mean - right_mean) / denom

        # Severe asymmetry might indicate lateral view or severe patient rotation
        if asymmetry_index > 0.45:
            return {
                "valid": False,
                "status": "INVALID",
                "reason": "Severe anatomical asymmetry detected (possible lateral projection or extreme rotation).",
                "details": {
                    "asymmetry_index": round(asymmetry_index, 3),
                    "aspect_ratio": round(aspect_ratio, 2)
                }
            }
        elif asymmetry_index > 0.28:
            return {
                "valid": True,
                "status": "WARNING",
                "reason": "Moderate patient rotation or asymmetry noted in thoracic field.",
                "details": {
                    "asymmetry_index": round(asymmetry_index, 3),
                    "aspect_ratio": round(aspect_ratio, 2)
                }
            }

        return {
            "valid": True,
            "status": "VALID",
            "reason": "Frontal thoracic alignment and bilateral projection verified.",
            "details": {
                "asymmetry_index": round(asymmetry_index, 3),
                "aspect_ratio": round(aspect_ratio, 2),
                "view": "Frontal (PA/AP)"
            }
        }

    elif modality_key in {"ct", "mri"}:
        # CT and MRI slices are typically near square (0.8 - 1.25)
        if aspect_ratio < 0.6 or aspect_ratio > 1.6:
            return {
                "valid": False,
                "status": "INVALID",
                "reason": f"Invalid slice geometry (aspect ratio {aspect_ratio:.2f}). Standard axial/coronal slice expected.",
                "details": {"aspect_ratio": round(aspect_ratio, 2)}
            }
        
        # Check center of mass / centering
        M = cv2.moments(gray)
        if M["m00"] > 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
            center_x_offset = abs(cX - width / 2) / (width / 2)
            center_y_offset = abs(cY - height / 2) / (height / 2)
            
            if center_x_offset > 0.4 or center_y_offset > 0.4:
                return {
                    "valid": True,
                    "status": "WARNING",
                    "reason": "Anatomical structures off-center within the slice frame.",
                    "details": {"aspect_ratio": round(aspect_ratio, 2), "center_offset": round(max(center_x_offset, center_y_offset), 2)}
                }

        return {
            "valid": True,
            "status": "VALID",
            "reason": "Valid slice geometry and anatomical orientation.",
            "details": {"aspect_ratio": round(aspect_ratio, 2)}
        }

    return {
        "valid": True,
        "status": "VALID",
        "reason": "Standard orientation verified.",
        "details": {"aspect_ratio": round(aspect_ratio, 2)}
    }
