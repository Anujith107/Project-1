import os
from pathlib import Path
from typing import Dict, Any, Tuple
from PIL import Image
import pydicom
from backend.app.config import (
    ALLOWED_EXTENSIONS,
    MAX_FILE_SIZE_BYTES,
    MIN_RESOLUTION,
    MAX_RESOLUTION
)

def validate_file_integrity(file_path: Path) -> Dict[str, Any]:
    """
    Validates file existence, size, extension, and standard image/DICOM integrity.
    """
    if not file_path.exists():
        return {
            "valid": False,
            "status": "INVALID",
            "reason": "File not found on server",
            "details": {}
        }

    file_size = file_path.stat().st_size
    if file_size == 0:
        return {
            "valid": False,
            "status": "INVALID",
            "reason": "Uploaded file is empty (0 bytes)",
            "details": {"file_size_bytes": 0}
        }

    if file_size > MAX_FILE_SIZE_BYTES:
        return {
            "valid": False,
            "status": "INVALID",
            "reason": f"File exceeds maximum allowed size of {MAX_FILE_SIZE_BYTES // (1024*1024)}MB",
            "details": {"file_size_bytes": file_size}
        }

    ext = file_path.suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        return {
            "valid": False,
            "status": "INVALID",
            "reason": f"Unsupported file extension '{ext}'. Supported: {', '.join(sorted(ALLOWED_EXTENSIONS))}",
            "details": {"extension": ext}
        }

    # If DICOM file
    if ext in {".dcm", ".dicom"}:
        try:
            dcm = pydicom.dcmread(str(file_path), force=True)
            if not hasattr(dcm, "pixel_array"):
                return {
                    "valid": False,
                    "status": "INVALID",
                    "reason": "DICOM file does not contain a valid pixel array",
                    "details": {"is_dicom": True}
                }
            shape = dcm.pixel_array.shape
            modality_tag = str(getattr(dcm, "Modality", "UNKNOWN"))
            patient_id = str(getattr(dcm, "PatientID", "ANONYMIZED"))
            return {
                "valid": True,
                "status": "VALID",
                "reason": "Valid DICOM file",
                "details": {
                    "is_dicom": True,
                    "dimensions": list(shape[-2:]),
                    "dicom_modality": modality_tag,
                    "patient_id": patient_id,
                    "file_size_bytes": file_size
                }
            }
        except Exception as e:
            return {
                "valid": False,
                "status": "INVALID",
                "reason": f"Corrupted or unreadable DICOM file: {str(e)}",
                "details": {"is_dicom": True, "error": str(e)}
            }

    # Standard Image (PNG/JPG)
    try:
        with Image.open(file_path) as img:
            img.verify()  # Verify integrity
            
        with Image.open(file_path) as img:
            width, height = img.size
            if width < MIN_RESOLUTION[0] or height < MIN_RESOLUTION[1]:
                return {
                    "valid": False,
                    "status": "INVALID",
                    "reason": f"Image resolution ({width}x{height}) is below minimum requirement ({MIN_RESOLUTION[0]}x{MIN_RESOLUTION[1]})",
                    "details": {"dimensions": [width, height], "is_dicom": False}
                }
            if width > MAX_RESOLUTION[0] or height > MAX_RESOLUTION[1]:
                return {
                    "valid": False,
                    "status": "INVALID",
                    "reason": f"Image resolution ({width}x{height}) exceeds maximum limit ({MAX_RESOLUTION[0]}x{MAX_RESOLUTION[1]})",
                    "details": {"dimensions": [width, height], "is_dicom": False}
                }
                
            return {
                "valid": True,
                "status": "VALID",
                "reason": "Valid image format and dimensions",
                "details": {
                    "is_dicom": False,
                    "dimensions": [width, height],
                    "format": img.format,
                    "file_size_bytes": file_size
                }
            }
    except Exception as e:
        return {
            "valid": False,
            "status": "INVALID",
            "reason": f"Corrupted or invalid image file: {str(e)}",
            "details": {"is_dicom": False, "error": str(e)}
        }
