import numpy as np
import cv2
from typing import Dict, Any
from backend.app.config import (
    MIN_LAPLACIAN_VARIANCE,
    MIN_STD_DEV,
    MIN_MEAN_INTENSITY,
    MAX_MEAN_INTENSITY
)

def validate_image_quality(image_array: np.ndarray) -> Dict[str, Any]:
    """
    Evaluates image quality metrics: blur (Laplacian variance), contrast (std dev),
    brightness (mean), and noise characteristics.
    Expects 2D grayscale uint8 array [H, W] or 3D [H, W, C].
    """
    if image_array.ndim == 3:
        if image_array.shape[2] == 3:
            gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
        elif image_array.shape[2] == 4:
            gray = cv2.cvtColor(image_array, cv2.COLOR_RGBA2GRAY)
        else:
            gray = image_array[:, :, 0]
    else:
        gray = image_array

    if gray.dtype != np.uint8:
        # Normalize to 0-255 uint8
        norm = cv2.normalize(gray, None, 0, 255, cv2.NORM_MINMAX)
        gray = norm.astype(np.uint8)

    # 1. Blur evaluation via Laplacian Variance
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    laplacian_var = float(laplacian.var())

    # 2. Brightness & Contrast
    mean_intensity = float(np.mean(gray))
    std_intensity = float(np.std(gray))

    # 3. Noise level estimation (median absolute deviation of high frequencies)
    h_diff = np.diff(gray, axis=1)
    noise_estimate = float(np.std(h_diff))

    # Quality rules
    issues = []
    warnings = []
    
    # Severe blur check
    if laplacian_var < 10.0:
        issues.append(f"Severe motion or focus blur detected (Focus score: {laplacian_var:.1f})")
    elif laplacian_var < MIN_LAPLACIAN_VARIANCE:
        warnings.append(f"Moderate blur detected (Focus score: {laplacian_var:.1f})")

    # Extreme brightness check
    if mean_intensity < MIN_MEAN_INTENSITY:
        issues.append("Image is severely underexposed (almost completely black)")
    elif mean_intensity > MAX_MEAN_INTENSITY:
        issues.append("Image is severely overexposed (almost completely white)")
    elif mean_intensity < 20.0 or mean_intensity > 230.0:
        warnings.append("Suboptimal lighting/exposure detected")

    # Contrast check
    if std_intensity < 4.0:
        issues.append("Severely flat image contrast (insufficient tissue definition)")
    elif std_intensity < MIN_STD_DEV:
        warnings.append("Low contrast level detected")

    # Status aggregation
    if issues:
        status = "INVALID"
        valid = False
        reason = "; ".join(issues)
    elif warnings:
        status = "WARNING"
        valid = True
        reason = "; ".join(warnings)
    else:
        status = "VALID"
        valid = True
        reason = "Good image clarity, contrast, and illumination"

    return {
        "valid": valid,
        "status": status,
        "reason": reason,
        "metrics": {
            "focus_score": round(laplacian_var, 2),
            "mean_brightness": round(mean_intensity, 2),
            "contrast_std": round(std_intensity, 2),
            "noise_level": round(noise_estimate, 2)
        }
    }
