from pathlib import Path
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from backend.app.config import UPLOAD_DIR
from backend.app.database.connection import get_db
from backend.app.services.pipeline_service import execute_scan_analysis_pipeline

router = APIRouter()

class AnalyzeScanRequest(BaseModel):
    saved_filename: str = Field(..., description="Saved filename from /api/upload")
    modality: str = Field(..., description="Modality key: xray, ct, or mri")
    patient_id: Optional[str] = Field(None, description="Optional Patient Identifier")

@router.post("/analyze")
def analyze_scan(request: AnalyzeScanRequest, db: Session = Depends(get_db)):
    """
    Executes the full pipeline: Validation -> Preprocessing -> Inference -> Severity -> Grad-CAM -> Persistence.
    """
    file_path = UPLOAD_DIR / request.saved_filename
    if not file_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan file '{request.saved_filename}' not found."
        )

    try:
        result = execute_scan_analysis_pipeline(
            file_path=file_path,
            modality_key=request.modality,
            db=db,
            patient_id=request.patient_id
        )
        return {
            "success": True,
            "data": result
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Analysis pipeline error: {str(e)}"
        )
