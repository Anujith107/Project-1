from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from backend.app.database.connection import get_db
from backend.app.database.crud import (
    list_scan_analyses,
    get_scan_analysis,
    get_dashboard_statistics
)

router = APIRouter()

@router.get("/history")
def get_history(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    modality: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Returns paginated list of past scan analyses.
    Filterable by modality ('xray', 'ct', 'mri') and severity ('NORMAL', 'MODERATE', 'CRITICAL').
    """
    scans = list_scan_analyses(db, skip=skip, limit=limit, modality=modality, severity=severity)
    return {
        "success": True,
        "count": len(scans),
        "data": [scan.to_dict() for scan in scans]
    }

@router.get("/result/{scan_id}")
def get_result_by_id(scan_id: str, db: Session = Depends(get_db)):
    """
    Retrieves the complete structured scan analysis report by scan ID.
    """
    scan = get_scan_analysis(db, scan_id)
    if not scan:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan analysis record '{scan_id}' not found."
        )
    return {
        "success": True,
        "data": scan.to_dict()
    }

@router.get("/stats")
def get_stats(db: Session = Depends(get_db)):
    """
    Retrieves real-time aggregated dashboard statistics from the SQLite database.
    """
    stats = get_dashboard_statistics(db)
    return {
        "success": True,
        "data": stats
    }
