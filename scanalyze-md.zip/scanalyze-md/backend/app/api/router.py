from fastapi import APIRouter
from backend.app.api.health import router as health_router
from backend.app.api.upload import router as upload_router
from backend.app.api.validate import router as validate_router
from backend.app.api.analyze import router as analyze_router
from backend.app.api.gradcam import router as gradcam_router
from backend.app.api.history import router as history_router

api_router = APIRouter(prefix="/api")

api_router.include_router(health_router, tags=["Health"])
api_router.include_router(upload_router, tags=["Upload"])
api_router.include_router(validate_router, tags=["Validation"])
api_router.include_router(analyze_router, tags=["Analysis"])
api_router.include_router(gradcam_router, tags=["Explainability"])
api_router.include_router(history_router, tags=["History & Statistics"])
