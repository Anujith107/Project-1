from pathlib import Path
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field
from backend.app.config import UPLOAD_DIR
from backend.app.services.validation_service import run_full_scan_validation

router = APIRouter()

class ValidateScanRequest(BaseModel):
    saved_filename: str = Field(..., description="Saved filename from /api/upload")
    modality: str = Field(..., description="Selected modality: xray, ct, or mri")

@router.post("/validate")
def validate_scan(request: ValidateScanRequest):
    """
    Validates file integrity, modality match, orientation, and image quality.
    Returns structured validation card data.
    """
    file_path = UPLOAD_DIR / request.saved_filename
    if not file_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan file '{request.saved_filename}' not found in upload directory."
        )

    passed, overall_status, report, _, _ = run_full_scan_validation(
        file_path=file_path,
        selected_modality=request.modality
    )

    return {
        "success": True,
        "valid": passed,
        "overall_status": overall_status,  # "VALID", "WARNING", "INVALID"
        "rejection_reason": report.get("rejection_reason"),
        "report": report
    }
