from fastapi import APIRouter
from backend.app.config import MODELS_DIR, DATABASE_URL
import torch

router = APIRouter()

@router.get("/health")
def health_check():
    """Health check endpoint confirming system status, CUDA, and model weight discovery."""
    xray_weights = (MODELS_DIR / "xray" / "model.pt").exists()
    ct_weights = (MODELS_DIR / "ct" / "model.pt").exists()
    mri_weights = (MODELS_DIR / "mri" / "model.pt").exists()

    return {
        "status": "healthy",
        "service": "ScanalyzeMD AI Backend",
        "version": "1.0.0",
        "cuda_available": torch.cuda.is_available(),
        "device": "cuda" if torch.cuda.is_available() else "cpu",
        "model_weights": {
            "xray": "trained" if xray_weights else "prototype",
            "ct": "trained" if ct_weights else "prototype",
            "mri": "trained" if mri_weights else "prototype"
        }
    }
