from pathlib import Path
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from backend.app.config import RESULTS_DIR, UPLOAD_DIR
from backend.app.database.connection import get_db
from backend.app.database.crud import get_scan_analysis
from backend.app.inference.model_loader import load_model_for_modality, get_device
from backend.app.explainability.gradcam import generate_gradcam_visualizations
from backend.app.preprocessing.common import read_scan_file
from backend.app.preprocessing.xray import preprocess_xray
from backend.app.preprocessing.ct import preprocess_ct
from backend.app.preprocessing.mri import preprocess_mri

router = APIRouter()

class GradCamRecalculateRequest(BaseModel):
    scan_id: str = Field(..., description="Unique Scan ID")
    target_class_idx: Optional[int] = Field(None, description="Optional target class index override")

@router.post("/gradcam")
def recalculate_gradcam(request: GradCamRecalculateRequest, db: Session = Depends(get_db)):
    """
    Recalculates or retrieves Grad-CAM for an existing scan or custom target class.
    """
    scan = get_scan_analysis(db, request.scan_id)
    if not scan:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan record '{request.scan_id}' not found."
        )

    if not scan.validation_passed:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Grad-CAM cannot be generated for scans that failed validation."
        )

    target_class = request.target_class_idx if request.target_class_idx is not None else int(scan.predicted_class_id or 0)

    # Check if image files exist
    upload_path = UPLOAD_DIR / scan.filename
    if not upload_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Source scan file is no longer available on the server."
        )

    raw_rgb, _ = read_scan_file(upload_path)
    modality_key = scan.modality_key

    if modality_key == "xray":
        input_tensor, display_rgb = preprocess_xray(raw_rgb)
    elif modality_key == "ct":
        input_tensor, display_rgb = preprocess_ct(raw_rgb)
    elif modality_key == "mri":
        input_tensor, display_rgb = preprocess_mri(raw_rgb)
    else:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Unknown modality {modality_key}")

    model, _ = load_model_for_modality(modality_key)
    device = get_device()

    prefix = RESULTS_DIR / scan.id
    cam_res = generate_gradcam_visualizations(
        model=model,
        input_tensor=input_tensor,
        raw_rgb_image=display_rgb,
        target_category_idx=target_class,
        output_prefix_path=prefix,
        device=device
    )

    return {
        "success": True,
        "scan_id": scan.id,
        "original_image_url": f"/api/images/{cam_res['original_filename']}",
        "gradcam_image_url": f"/api/images/{cam_res['gradcam_filename']}",
        "heatmap_image_url": f"/api/images/{cam_res['heatmap_filename']}"
    }
