import uuid
import shutil
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, status
from backend.app.config import UPLOAD_DIR, ALLOWED_EXTENSIONS, MAX_FILE_SIZE_BYTES
from backend.app.validation.file_validator import validate_file_integrity
from backend.app.preprocessing.common import read_scan_file

router = APIRouter()

@router.post("/upload")
async def upload_scan_file(
    file: UploadFile = File(...),
    modality: Optional[str] = Form(None)
):
    """
    Accepts medical scan uploads (DICOM, PNG, JPG, JPEG).
    Saves to uploads directory and returns file metadata and detected modality.
    """
    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file format '{ext}'. Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
        )

    # Save to disk with unique ID
    unique_filename = f"{uuid.uuid4().hex[:10]}_{Path(file.filename).name}"
    target_path = UPLOAD_DIR / unique_filename

    try:
        with open(target_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to save uploaded file: {str(e)}"
        )

    # Quick integrity check
    integrity = validate_file_integrity(target_path)
    if not integrity["valid"]:
        # Remove corrupt file
        if target_path.exists():
            target_path.unlink()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=integrity["reason"]
        )

    # Detect modality if DICOM
    detected_modality = modality
    dicom_patient_id = None
    if ext in {".dcm", ".dicom"}:
        try:
            _, meta = read_scan_file(target_path)
            dcm_mod = meta.get("Modality", "").upper()
            if dcm_mod in {"CR", "DX", "RG"}:
                detected_modality = "xray"
            elif dcm_mod == "CT":
                detected_modality = "ct"
            elif dcm_mod == "MR":
                detected_modality = "mri"
            dicom_patient_id = meta.get("PatientID")
        except Exception:
            pass

    return {
        "success": True,
        "filename": file.filename,
        "saved_filename": unique_filename,
        "file_path": str(target_path),
        "file_size_bytes": target_path.stat().st_size,
        "detected_modality": detected_modality or "xray",
        "dicom_patient_id": dicom_patient_id,
        "integrity": integrity
    }
