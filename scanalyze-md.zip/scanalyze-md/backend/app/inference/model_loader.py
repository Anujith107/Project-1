import os
from pathlib import Path
from typing import Tuple, Dict, Any, Optional
import torch
import torch.nn as nn
from backend.app.config import MODELS_DIR
from backend.app.inference.xray_model import XRayResNet18
from backend.app.inference.ct_model import CTResNet18
from backend.app.inference.mri_model import MRIResNet18

_model_cache: Dict[str, Tuple[nn.Module, Dict[str, Any]]] = {}

def get_device() -> torch.device:
    """Returns CUDA device if available, otherwise CPU."""
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")

def load_model_for_modality(modality_key: str) -> Tuple[nn.Module, Dict[str, Any]]:
    """
    Retrieves or loads the specific PyTorch model for the given modality ('xray', 'ct', 'mri').
    Returns (model, metadata_dict).
    """
    modality_key = modality_key.lower().strip()
    if modality_key in _model_cache:
        return _model_cache[modality_key]

    device = get_device()
    weights_file = MODELS_DIR / modality_key / "model.pt"

    if modality_key == "xray":
        model = XRayResNet18(num_classes=3, pretrained=True)
        model_name = "ResNet18-ChestXRay"
    elif modality_key == "ct":
        model = CTResNet18(num_classes=2, pretrained=True)
        model_name = "ResNet18-CTLesion"
    elif modality_key == "mri":
        model = MRIResNet18(num_classes=2, pretrained=True)
        model_name = "ResNet18-MRILesion"
    else:
        raise ValueError(f"Unsupported modality key: {modality_key}")

    is_trained_weights = False
    if weights_file.exists():
        try:
            state_dict = torch.load(str(weights_file), map_location=device, weights_only=True)
            model.load_state_dict(state_dict)
            is_trained_weights = True
        except Exception as e:
            print(f"Warning: Could not load trained weights from {weights_file}: {e}. Running with initialized base model.")
            is_trained_weights = False

    model.to(device)
    model.eval()

    meta = {
        "model_name": model_name,
        "device": str(device),
        "is_prototype_model": not is_trained_weights,
        "weights_path": str(weights_file) if is_trained_weights else None,
        "status_message": "Trained project weights loaded" if is_trained_weights else "Prototype Model (Pretrained Transfer Learning Base)"
    }

    _model_cache[modality_key] = (model, meta)
    return model, meta

def save_model_weights(model: nn.Module, modality_key: str) -> Path:
    """Saves model weights to models/<modality_key>/model.pt."""
    modality_key = modality_key.lower().strip()
    save_dir = MODELS_DIR / modality_key
    save_dir.mkdir(parents=True, exist_ok=True)
    weights_path = save_dir / "model.pt"
    torch.save(model.state_dict(), str(weights_path))
    # Clear cache so next inference reloads updated weights
    if modality_key in _model_cache:
        del _model_cache[modality_key]
    return weights_path
