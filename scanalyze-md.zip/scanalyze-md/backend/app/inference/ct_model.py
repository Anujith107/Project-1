import torch
import torch.nn as nn
from torchvision.models import resnet18, ResNet18_Weights

class CTResNet18(nn.Module):
    """
    CT scan anomaly classifier based on ResNet-18 architecture.
    Target layer for Grad-CAM: self.backbone.layer4[-1]
    """
    def __init__(self, num_classes: int = 2, pretrained: bool = True):
        super().__init__()
        weights = ResNet18_Weights.DEFAULT if pretrained else None
        self.backbone = resnet18(weights=weights)
        in_features = self.backbone.fc.in_features
        
        self.backbone.fc = nn.Sequential(
            nn.Dropout(p=0.3),
            nn.Linear(in_features, num_classes)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.backbone(x)

    def get_target_layer(self):
        """Returns the final convolutional layer for Grad-CAM explainability."""
        return [self.backbone.layer4[-1]]
