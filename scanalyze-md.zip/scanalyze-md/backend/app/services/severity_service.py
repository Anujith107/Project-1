from typing import Dict, Any, Optional

def assess_clinical_severity(
    modality_key: str,
    class_id: int,
    class_name: str,
    confidence: Optional[float],
    configured_severity: Optional[str] = None
) -> str:
    """
    Evaluates clinical severity based on the predicted class, confidence, and modality.
    Possible outputs: 'NORMAL', 'MODERATE', 'CRITICAL', 'Not Determined'.
    """
    if confidence is None or confidence < 0.35:
        return "Not Determined"

    # If class is Normal
    if class_id == 0 or "normal" in class_name.lower():
        return "NORMAL"

    # Use configured default if provided
    if configured_severity in {"NORMAL", "MODERATE", "CRITICAL"}:
        # High confidence critical findings (e.g. hemorrhage, large mass)
        if configured_severity == "CRITICAL" and confidence < 0.50:
            return "MODERATE"
        return configured_severity

    # Modality specific logic
    if modality_key == "xray":
        if class_id == 1:  # Possible Pneumonia / Opacity
            return "CRITICAL" if confidence > 0.85 else "MODERATE"
        elif class_id == 2:  # Other Abnormality
            return "MODERATE"
    elif modality_key in {"ct", "mri"}:
        if class_id == 1:  # Lesion / Hemorrhage / Mass
            return "CRITICAL" if confidence > 0.60 else "MODERATE"

    return "MODERATE"
