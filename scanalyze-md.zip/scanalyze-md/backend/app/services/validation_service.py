from pathlib import Path
from typing import Dict, Any, Tuple, Optional
import numpy as np
from backend.app.validation.file_validator import validate_file_integrity
from backend.app.validation.quality_validator import validate_image_quality
from backend.app.validation.orientation_validator import validate_scan_orientation
from backend.app.validation.modality_validator import validate_modality_compatibility
from backend.app.preprocessing.common import read_scan_file

def run_full_scan_validation(
    file_path: Path,
    selected_modality: str
) -> Tuple[bool, str, Dict[str, Any], Optional[np.ndarray], Dict[str, Any]]:
    """
    Executes the 4-step validation pipeline:
    1. File Integrity Validation
    2. Modality Compatibility Validation
    3. Orientation & Projection Validation
    4. Image Quality Validation (Blur, Contrast, Noise)

    Returns:
      (passed: bool, overall_status: str ("VALID"|"WARNING"|"INVALID"),
       validation_report: dict, raw_image_rgb: ndarray or None, dicom_meta: dict)
    """
    # 1. File Integrity
    file_val = validate_file_integrity(file_path)
    if not file_val["valid"]:
        report = {
            "overall_status": "INVALID",
            "passed": False,
            "rejection_reason": file_val["reason"],
            "checks": {
                "file_integrity": file_val,
                "modality": {"status": "SKIPPED", "valid": False, "reason": "File check failed"},
                "orientation": {"status": "SKIPPED", "valid": False, "reason": "File check failed"},
                "quality": {"status": "SKIPPED", "valid": False, "reason": "File check failed"}
            }
        }
        return False, "INVALID", report, None, {}

    # Read image array and DICOM metadata
    try:
        image_rgb, dicom_meta = read_scan_file(file_path)
    except Exception as e:
        report = {
            "overall_status": "INVALID",
            "passed": False,
            "rejection_reason": f"Unable to decode scan pixels: {str(e)}",
            "checks": {
                "file_integrity": file_val,
                "modality": {"status": "SKIPPED", "valid": False, "reason": "Pixel read failed"},
                "orientation": {"status": "SKIPPED", "valid": False, "reason": "Pixel read failed"},
                "quality": {"status": "SKIPPED", "valid": False, "reason": "Pixel read failed"}
            }
        }
        return False, "INVALID", report, None, {}

    # 2. Modality Compatibility
    modality_val = validate_modality_compatibility(
        selected_modality=selected_modality,
        image_array=image_rgb,
        dicom_meta=dicom_meta
    )
    if not modality_val["valid"]:
        report = {
            "overall_status": "INVALID",
            "passed": False,
            "rejection_reason": modality_val["reason"],
            "checks": {
                "file_integrity": file_val,
                "modality": modality_val,
                "orientation": {"status": "SKIPPED", "valid": False, "reason": "Modality mismatch"},
                "quality": {"status": "SKIPPED", "valid": False, "reason": "Modality mismatch"}
            }
        }
        return False, "INVALID", report, image_rgb, dicom_meta

    # 3. Orientation & Projection
    orientation_val = validate_scan_orientation(
        image_array=image_rgb,
        modality_key=selected_modality.lower(),
        dicom_meta=dicom_meta
    )
    if not orientation_val["valid"]:
        report = {
            "overall_status": "INVALID",
            "passed": False,
            "rejection_reason": orientation_val["reason"],
            "checks": {
                "file_integrity": file_val,
                "modality": modality_val,
                "orientation": orientation_val,
                "quality": {"status": "SKIPPED", "valid": False, "reason": "Orientation check failed"}
            }
        }
        return False, "INVALID", report, image_rgb, dicom_meta

    # 4. Image Quality
    quality_val = validate_image_quality(image_rgb)
    if not quality_val["valid"]:
        report = {
            "overall_status": "INVALID",
            "passed": False,
            "rejection_reason": quality_val["reason"],
            "checks": {
                "file_integrity": file_val,
                "modality": modality_val,
                "orientation": orientation_val,
                "quality": quality_val
            }
        }
        return False, "INVALID", report, image_rgb, dicom_meta

    # Aggregate Overall Status (WARNING if any check produced a warning, else VALID)
    has_warning = any(
        check.get("status") == "WARNING"
        for check in [file_val, modality_val, orientation_val, quality_val]
    )
    overall_status = "WARNING" if has_warning else "VALID"

    report = {
        "overall_status": overall_status,
        "passed": True,
        "rejection_reason": None,
        "checks": {
            "file_integrity": file_val,
            "modality": modality_val,
            "orientation": orientation_val,
            "quality": quality_val
        }
    }
    return True, overall_status, report, image_rgb, dicom_meta
