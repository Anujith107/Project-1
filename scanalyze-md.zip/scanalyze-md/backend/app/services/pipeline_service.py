import uuid
from pathlib import Path
from typing import Dict, Any, Optional
import torch
import torch.nn.functional as F
from sqlalchemy.orm import Session

from backend.app.config import RESULTS_DIR, load_classes_config
from backend.app.services.validation_service import run_full_scan_validation
from backend.app.services.severity_service import assess_clinical_severity
from backend.app.preprocessing.xray import preprocess_xray
from backend.app.preprocessing.ct import preprocess_ct
from backend.app.preprocessing.mri import preprocess_mri
from backend.app.inference.model_loader import load_model_for_modality, get_device
from backend.app.explainability.gradcam import generate_gradcam_visualizations
from backend.app.database.crud import create_scan_analysis

MODALITY_NAMES = {
    "xray": "Chest X-Ray",
    "ct": "Computed Tomography (CT)",
    "mri": "Magnetic Resonance Imaging (MRI)"
}

def execute_scan_analysis_pipeline(
    file_path: Path,
    modality_key: str,
    db: Session,
    patient_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Full end-to-end medical scan analysis pipeline:
    1. Validation (File, Modality, Orientation, Quality)
    2. Modality Preprocessing
    3. PyTorch Model Inference
    4. Anomaly Detection & Probability
    5. Severity Assessment
    6. Grad-CAM Explainability Generation
    7. Database Persistence
    """
    modality_key = modality_key.lower().strip()
    if not patient_id:
        patient_id = f"PT-{uuid.uuid4().hex[:6].upper()}"

    scan_id = str(uuid.uuid4())
    modality_display = MODALITY_NAMES.get(modality_key, modality_key.upper())

    # Step 1: Scan Validation
    passed, overall_status, val_report, raw_image_rgb, dicom_meta = run_full_scan_validation(
        file_path=file_path,
        selected_modality=modality_key
    )

    file_size = file_path.stat().st_size if file_path.exists() else 0

    # If scan validation fails, do NOT continue to AI inference or Grad-CAM
    if not passed or raw_image_rgb is None:
        rejection_reason = val_report.get("rejection_reason", "Scan failed validation checks")
        db_record = {
            "id": scan_id,
            "patient_id": patient_id,
            "filename": file_path.name,
            "file_size_bytes": file_size,
            "modality": modality_display,
            "modality_key": modality_key,
            "validation_status": "INVALID",
            "validation_passed": False,
            "validation_details": val_report,
            "rejection_reason": rejection_reason,
            "anomaly_detected": False,
            "anomaly_name": None,
            "predicted_class_id": None,
            "predicted_class_name": None,
            "confidence": None,
            "severity": "Not Determined",
            "description": f"Validation Failed: {rejection_reason}",
            "symptoms": None,
            "suggestions": "Please upload a supported, valid scan meeting diagnostic resolution and frontal positioning requirements.",
            "original_image_path": None,
            "gradcam_image_path": None,
            "original_image_url": None,
            "gradcam_image_url": None,
            "model_name": None,
            "is_prototype_model": False
        }
        saved = create_scan_analysis(db, db_record)
        return saved.to_dict()

    # Step 2: Modality Preprocessing
    if modality_key == "xray":
        input_tensor, preprocessed_display = preprocess_xray(raw_image_rgb)
    elif modality_key == "ct":
        input_tensor, preprocessed_display = preprocess_ct(raw_image_rgb)
    elif modality_key == "mri":
        input_tensor, preprocessed_display = preprocess_mri(raw_image_rgb)
    else:
        raise ValueError(f"Unknown modality: {modality_key}")

    # Step 3: AI Inference
    model, model_meta = load_model_for_modality(modality_key)
    device = get_device()
    input_tensor = input_tensor.to(device)

    with torch.no_grad():
        logits = model(input_tensor)
        probabilities = F.softmax(logits, dim=1).cpu().numpy()[0]

    predicted_idx = int(torch.argmax(logits, dim=1).item())
    pred_confidence = float(probabilities[predicted_idx])

    # Step 4: Class definitions and Anomaly Detection
    classes_config = load_classes_config()
    mod_classes = classes_config.get(modality_key, {}).get("classes", [])

    if predicted_idx < len(mod_classes):
        target_class_info = mod_classes[predicted_idx]
        class_name = target_class_info.get("name", f"Class {predicted_idx}")
        base_severity = target_class_info.get("severity", "NORMAL")
        description = target_class_info.get("description", "")
        symptoms = target_class_info.get("symptoms", "")
        suggestions = target_class_info.get("suggestions", "")
    else:
        class_name = f"Finding {predicted_idx}"
        base_severity = "MODERATE" if predicted_idx > 0 else "NORMAL"
        description = "Radiological finding detected in the scanned region."
        symptoms = "Clinical correlation advised."
        suggestions = "Further clinical review recommended."

    anomaly_detected = (predicted_idx != 0)
    anomaly_status_text = "Detected" if anomaly_detected else "None Detected (Normal)"

    # Step 5: Severity Assessment
    final_severity = assess_clinical_severity(
        modality_key=modality_key,
        class_id=predicted_idx,
        class_name=class_name,
        confidence=pred_confidence,
        configured_severity=base_severity
    )

    # Step 6: Real Grad-CAM Visualization
    prefix_path = RESULTS_DIR / scan_id
    cam_results = generate_gradcam_visualizations(
        model=model,
        input_tensor=input_tensor,
        raw_rgb_image=preprocessed_display,
        target_category_idx=predicted_idx,
        output_prefix_path=prefix_path,
        device=device
    )

    orig_url = f"/api/images/{cam_results['original_filename']}"
    gradcam_url = f"/api/images/{cam_results['gradcam_filename']}"

    # Step 7: Local Database Persistence
    db_record = {
        "id": scan_id,
        "patient_id": patient_id,
        "filename": file_path.name,
        "file_size_bytes": file_size,
        "modality": modality_display,
        "modality_key": modality_key,
        "validation_status": overall_status,
        "validation_passed": True,
        "validation_details": val_report,
        "rejection_reason": None,
        "anomaly_detected": anomaly_detected,
        "anomaly_name": class_name if anomaly_detected else "Normal",
        "predicted_class_id": str(predicted_idx),
        "predicted_class_name": class_name,
        "confidence": pred_confidence,
        "severity": final_severity,
        "description": description,
        "symptoms": symptoms,
        "suggestions": suggestions,
        "original_image_path": cam_results["original_image_path"],
        "gradcam_image_path": cam_results["gradcam_image_path"],
        "original_image_url": orig_url,
        "gradcam_image_url": gradcam_url,
        "model_name": model_meta.get("model_name"),
        "is_prototype_model": model_meta.get("is_prototype_model", False)
    }

    saved_scan = create_scan_analysis(db, db_record)
    return saved_scan.to_dict()
