from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend.app.config import (
    CORS_ORIGINS,
    RESULTS_DIR,
    UPLOAD_DIR,
    SAMPLE_DATA_DIR
)
from backend.app.database.connection import init_db
from backend.app.api.router import api_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize SQLite database schema
    init_db()
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    SAMPLE_DATA_DIR.mkdir(parents=True, exist_ok=True)
    yield

app = FastAPI(
    title="ScanalyzeMD API",
    description="Explainable Multimodal Medical Imaging Assistant Backend",
    version="1.0.0",
    lifespan=lifespan
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve result images
@app.get("/api/images/{filename}")
async def serve_result_image(filename: str):
    file_path = RESULTS_DIR / filename
    if not file_path.exists():
        # Check upload dir as fallback
        file_path = UPLOAD_DIR / filename
    if not file_path.exists():
        return JSONResponse(status_code=404, content={"detail": "Image not found"})
    return FileResponse(file_path)

# Serve sample images
@app.get("/api/samples/{filename}")
async def serve_sample_image(filename: str):
    file_path = SAMPLE_DATA_DIR / filename
    if not file_path.exists():
        return JSONResponse(status_code=404, content={"detail": "Sample image not found"})
    return FileResponse(file_path)

# Mount API router
app.include_router(api_router)

@app.get("/")
def root():
    return {
        "app": "ScanalyzeMD",
        "description": "Explainable Multimodal Medical Imaging Assistant",
        "docs": "/docs",
        "health": "/api/health"
    }

if __name__ == "__main__":
    import uvicorn
    from backend.app.config import API_HOST, API_PORT
    uvicorn.run("backend.app.main:app", host=API_HOST, port=API_PORT, reload=True)
