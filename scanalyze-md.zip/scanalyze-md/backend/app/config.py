import os
import json
from pathlib import Path
from typing import Dict, Any

# Root directories
BACKEND_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = BACKEND_DIR.parent

def _get_writable_dir(preferred_path: Path, fallback_subdir: str) -> Path:
    """Returns preferred path if writable, otherwise falls back to local AppData."""
    try:
        preferred_path.mkdir(parents=True, exist_ok=True)
        test_file = preferred_path / ".test_write"
        with open(test_file, "w") as f:
            f.write("ok")
        test_file.unlink(missing_ok=True)
        return preferred_path
    except Exception:
        local_base = Path(os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))) / "ScanalyzeMD"
        fallback_path = local_base / fallback_subdir
        fallback_path.mkdir(parents=True, exist_ok=True)
        return fallback_path

UPLOAD_DIR = _get_writable_dir(BACKEND_DIR / "uploads", "uploads")
RESULTS_DIR = _get_writable_dir(BACKEND_DIR / "results", "results")
SAMPLE_DATA_DIR = _get_writable_dir(BACKEND_DIR / "sample_data", "sample_data")
MODELS_DIR = _get_writable_dir(PROJECT_ROOT / "models", "models")
CONFIG_DIR = PROJECT_ROOT / "config"
CLASSES_CONFIG_PATH = CONFIG_DIR / "classes.json"

for sub in ["xray", "ct", "mri"]:
    (MODELS_DIR / sub).mkdir(parents=True, exist_ok=True)

# Database
DB_PATH = _get_writable_dir(BACKEND_DIR, "db") / "scanalyze.db"
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DB_PATH}")

# Server configuration
API_HOST = os.getenv("API_HOST", "127.0.0.1")
API_PORT = int(os.getenv("API_PORT", 8000))
CORS_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "*"
]

# File constraints
MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024  # 50 MB
ALLOWED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".dcm", ".dicom"}
ALLOWED_MIME_TYPES = {
    "image/png",
    "image/jpeg",
    "application/dicom",
    "application/octet-stream"
}

# Image Quality Thresholds
MIN_RESOLUTION = (128, 128)
MAX_RESOLUTION = (4096, 4096)
MIN_LAPLACIAN_VARIANCE = 25.0  # Blur threshold
MIN_STD_DEV = 8.0             # Contrast threshold
MIN_MEAN_INTENSITY = 10.0      # Too dark threshold
MAX_MEAN_INTENSITY = 245.0     # Overexposed threshold

def load_classes_config() -> Dict[str, Any]:
    """Loads classes, descriptions, symptoms, and suggestions from config/classes.json."""
    if CLASSES_CONFIG_PATH.exists():
        with open(CLASSES_CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}
