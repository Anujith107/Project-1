from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import desc
from backend.app.database.models import ScanAnalysis

def create_scan_analysis(db: Session, scan_data: Dict[str, Any]) -> ScanAnalysis:
    """Inserts a new scan analysis record."""
    scan = ScanAnalysis(**scan_data)
    db.add(scan)
    db.commit()
    db.refresh(scan)
    return scan

def get_scan_analysis(db: Session, scan_id: str) -> Optional[ScanAnalysis]:
    """Retrieves a scan analysis record by ID."""
    return db.query(ScanAnalysis).filter(ScanAnalysis.id == scan_id).first()

def list_scan_analyses(
    db: Session,
    skip: int = 0,
    limit: int = 50,
    modality: Optional[str] = None,
    severity: Optional[str] = None
) -> List[ScanAnalysis]:
    """Lists scan analyses with optional filtering."""
    query = db.query(ScanAnalysis)
    if modality:
        query = query.filter(ScanAnalysis.modality_key == modality.lower())
    if severity:
        query = query.filter(ScanAnalysis.severity == severity.upper())
    return query.order_by(desc(ScanAnalysis.created_at)).offset(skip).limit(limit).all()

def get_dashboard_statistics(db: Session) -> Dict[str, Any]:
    """Calculates compact statistics from the SQLite database."""
    total_analyses = db.query(ScanAnalysis).count()
    valid_scans = db.query(ScanAnalysis).filter(ScanAnalysis.validation_status.in_(["VALID", "WARNING"])).count()
    abnormal_findings = db.query(ScanAnalysis).filter(ScanAnalysis.anomaly_detected == True).count()
    recent_analyses = db.query(ScanAnalysis).order_by(desc(ScanAnalysis.created_at)).limit(5).all()

    # Modality distribution
    xray_count = db.query(ScanAnalysis).filter(ScanAnalysis.modality_key == "xray").count()
    ct_count = db.query(ScanAnalysis).filter(ScanAnalysis.modality_key == "ct").count()
    mri_count = db.query(ScanAnalysis).filter(ScanAnalysis.modality_key == "mri").count()

    # Severity distribution
    normal_count = db.query(ScanAnalysis).filter(ScanAnalysis.severity == "NORMAL").count()
    moderate_count = db.query(ScanAnalysis).filter(ScanAnalysis.severity == "MODERATE").count()
    critical_count = db.query(ScanAnalysis).filter(ScanAnalysis.severity == "CRITICAL").count()

    return {
        "total_analyses": total_analyses,
        "valid_scans": valid_scans,
        "abnormal_findings": abnormal_findings,
        "recent_analyses_count": len(recent_analyses),
        "recent_analyses": [scan.to_dict() for scan in recent_analyses],
        "modalities": {
            "xray": xray_count,
            "ct": ct_count,
            "mri": mri_count
        },
        "severities": {
            "NORMAL": normal_count,
            "MODERATE": moderate_count,
            "CRITICAL": critical_count
        }
    }
