import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Float, Boolean, DateTime, Text, JSON
from backend.app.database.connection import Base

def generate_uuid() -> str:
    return str(uuid.uuid4())

class ScanAnalysis(Base):
    __tablename__ = "scan_analyses"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    patient_id = Column(String(50), nullable=False, index=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    
    # Scan Details
    filename = Column(String(255), nullable=False)
    file_size_bytes = Column(Float, nullable=False)
    modality = Column(String(50), nullable=False)  # "Chest X-Ray", "CT", "MRI"
    modality_key = Column(String(20), nullable=False)  # "xray", "ct", "mri"
    
    # Validation
    validation_status = Column(String(20), nullable=False)  # "VALID", "WARNING", "INVALID"
    validation_passed = Column(Boolean, default=True)
    validation_details = Column(JSON, nullable=True)
    rejection_reason = Column(String(255), nullable=True)
    
    # Analysis & Inference
    anomaly_detected = Column(Boolean, default=False)
    anomaly_name = Column(String(100), nullable=True)
    predicted_class_id = Column(String(50), nullable=True)
    predicted_class_name = Column(String(100), nullable=True)
    confidence = Column(Float, nullable=True)
    severity = Column(String(30), nullable=False, default="NORMAL")  # "NORMAL", "MODERATE", "CRITICAL", "Not Determined"
    
    # Structured Report Fields
    description = Column(Text, nullable=True)
    symptoms = Column(Text, nullable=True)
    suggestions = Column(Text, nullable=True)
    
    # Visual Explanations
    original_image_path = Column(String(255), nullable=True)
    gradcam_image_path = Column(String(255), nullable=True)
    original_image_url = Column(String(255), nullable=True)
    gradcam_image_url = Column(String(255), nullable=True)
    
    # Model Metadata
    model_name = Column(String(100), nullable=True)
    is_prototype_model = Column(Boolean, default=False)

    def to_dict(self):
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "filename": self.filename,
            "file_size_bytes": self.file_size_bytes,
            "modality": self.modality,
            "modality_key": self.modality_key,
            "validation_status": self.validation_status,
            "validation_passed": self.validation_passed,
            "validation_details": self.validation_details,
            "rejection_reason": self.rejection_reason,
            "anomaly_detected": self.anomaly_detected,
            "anomaly_name": self.anomaly_name,
            "predicted_class_id": self.predicted_class_id,
            "predicted_class_name": self.predicted_class_name,
            "confidence": round(self.confidence, 4) if self.confidence is not None else None,
            "confidence_percentage": round(self.confidence * 100, 1) if self.confidence is not None else None,
            "severity": self.severity,
            "description": self.description,
            "symptoms": self.symptoms,
            "suggestions": self.suggestions,
            "original_image_url": self.original_image_url,
            "gradcam_image_url": self.gradcam_image_url,
            "model_name": self.model_name,
            "is_prototype_model": self.is_prototype_model
        }
