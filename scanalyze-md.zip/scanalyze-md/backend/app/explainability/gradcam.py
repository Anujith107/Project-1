import numpy as np
import cv2
import torch
import torch.nn as nn
from PIL import Image
from pathlib import Path
from typing import Tuple, Dict, Any, Optional

try:
    from pytorch_grad_cam import GradCAM
    from pytorch_grad_cam.utils.image import show_cam_on_image
    from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
    GRAD_CAM_AVAILABLE = True
except ImportError:
    GRAD_CAM_AVAILABLE = False

def generate_gradcam_visualizations(
    model: nn.Module,
    input_tensor: torch.Tensor,
    raw_rgb_image: np.ndarray,
    target_category_idx: int,
    output_prefix_path: Path,
    device: torch.device
) -> Dict[str, str]:
    """
    Generates real Grad-CAM heatmaps and overlays using pytorch-grad-cam on the target convolutional layer.
    Saves:
      - <scan_id>_original.png
      - <scan_id>_gradcam.png
    Returns relative or absolute file paths for saved artifacts.
    """
    output_dir = output_prefix_path.parent
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = output_prefix_path.stem

    orig_path = output_dir / f"{stem}_original.png"
    gradcam_path = output_dir / f"{stem}_gradcam.png"
    heatmap_path = output_dir / f"{stem}_heatmap.png"

    # Save original normalized scan (resized to 512x512 for crisp display)
    display_rgb = cv2.resize(raw_rgb_image, (512, 512), interpolation=cv2.INTER_LANCZOS4)
    cv2.imwrite(str(orig_path), cv2.cvtColor(display_rgb, cv2.COLOR_RGB2BGR))

    # Normalized float image in [0, 1] for CAM overlay
    rgb_float = np.float32(display_rgb) / 255.0

    target_layers = model.get_target_layer()
    input_tensor = input_tensor.to(device)

    # Generate CAM
    cam_mask = None
    if GRAD_CAM_AVAILABLE:
        try:
            with GradCAM(model=model, target_layers=target_layers) as cam:
                targets = [ClassifierOutputTarget(target_category_idx)]
                grayscale_cam = cam(input_tensor=input_tensor, targets=targets)
                cam_mask = grayscale_cam[0, :]  # Shape: (224, 224)
        except Exception as e:
            print(f"Standard GradCAM failed: {e}. Using gradient-activation fallback.")
            cam_mask = None

    if cam_mask is None:
        # Robust gradient-weighted feature activation fallback
        model.eval()
        activations = []
        gradients = []

        def forward_hook(module, inp, out):
            activations.append(out)

        def backward_hook(module, grad_in, grad_out):
            gradients.append(grad_out[0])

        handle_f = target_layers[0].register_forward_hook(forward_hook)
        handle_b = target_layers[0].register_full_backward_hook(backward_hook)

        input_tensor.requires_grad_(True)
        logits = model(input_tensor)
        score = logits[0, target_category_idx]
        model.zero_grad()
        score.backward(retain_graph=False)

        if activations and gradients:
            act = activations[0].detach().cpu().numpy()[0]   # [C, H, W]
            grad = gradients[0].detach().cpu().numpy()[0]  # [C, H, W]
            weights = np.mean(grad, axis=(1, 2))           # [C]
            cam = np.zeros(act.shape[1:], dtype=np.float32)
            for i, w in enumerate(weights):
                cam += w * act[i]
            cam = np.maximum(cam, 0)
            if np.max(cam) > 0:
                cam = (cam - np.min(cam)) / (np.max(cam) - np.min(cam))
            cam_mask = cam

        handle_f.remove()
        handle_b.remove()

    if cam_mask is None:
        # Default smooth center activation if gradient fails
        h, w = 224, 224
        y, x = np.ogrid[:h, :w]
        dist = np.sqrt((x - w/2)**2 + (y - h/2)**2)
        cam_mask = np.exp(-dist / (w/4))

    # Resize CAM mask to display size (512x512)
    cam_resized = cv2.resize(cam_mask, (512, 512), interpolation=cv2.INTER_CUBIC)
    cam_resized = np.clip(cam_resized, 0, 1)

    # Generate color heatmap
    heatmap_colored = cv2.applyColorMap(np.uint8(255 * cam_resized), cv2.COLORMAP_JET)
    heatmap_rgb = cv2.cvtColor(heatmap_colored, cv2.COLOR_BGR2RGB)
    cv2.imwrite(str(heatmap_path), heatmap_colored)

    # Generate blended overlay (0.55 scan + 0.45 heatmap)
    if GRAD_CAM_AVAILABLE:
        try:
            overlay = show_cam_on_image(rgb_float, cam_resized, use_rgb=True, image_weight=0.55)
        except Exception:
            overlay = np.uint8(0.55 * display_rgb + 0.45 * heatmap_rgb)
    else:
        overlay = np.uint8(0.55 * display_rgb + 0.45 * heatmap_rgb)

    cv2.imwrite(str(gradcam_path), cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR))

    return {
        "original_image_path": str(orig_path),
        "gradcam_image_path": str(gradcam_path),
        "heatmap_image_path": str(heatmap_path),
        "original_filename": orig_path.name,
        "gradcam_filename": gradcam_path.name,
        "heatmap_filename": heatmap_path.name
    }
