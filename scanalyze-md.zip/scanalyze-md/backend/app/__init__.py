# ScanalyzeMD backend app package
__version__ = "1.0.0"
