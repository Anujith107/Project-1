import os
from pathlib import Path
from typing import Tuple, List, Optional
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image

class MedicalImageDataset(Dataset):
    """
    Standard Medical Image Dataset supporting folder structure:
    root_dir/
      class_0/
        img1.png ...
      class_1/
        img2.png ...
    """
    def __init__(self, root_dir: Path, transform=None):
        self.root_dir = Path(root_dir)
        self.transform = transform
        self.samples: List[Tuple[Path, int]] = []
        self.classes: List[str] = []

        if self.root_dir.exists():
            class_dirs = sorted([d for d in self.root_dir.iterdir() if d.is_dir()])
            self.classes = [d.name for d in class_dirs]
            for idx, c_dir in enumerate(class_dirs):
                for img_path in c_dir.glob("*.*"):
                    if img_path.suffix.lower() in {".png", ".jpg", ".jpeg", ".dcm"}:
                        self.samples.append((img_path, idx))

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        img_path, label = self.samples[idx]
        img = Image.open(img_path).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, label

def get_medical_transforms(is_train: bool = True) -> transforms.Compose:
    """Standard train/eval augmentation pipeline for medical radiographs."""
    if is_train:
        return transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomRotation(degrees=10),
            transforms.ColorJitter(brightness=0.15, contrast=0.15),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
    else:
        return transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
