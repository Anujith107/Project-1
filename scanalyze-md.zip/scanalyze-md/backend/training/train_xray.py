import argparse
from pathlib import Path
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split

from backend.app.inference.xray_model import XRayResNet18
from backend.app.inference.model_loader import save_model_weights, get_device
from backend.training.dataset_utils import MedicalImageDataset, get_medical_transforms
from backend.training.evaluate import evaluate_model

def train_xray(
    data_dir: Path,
    epochs: int = 10,
    batch_size: int = 16,
    lr: float = 1e-4
):
    device = get_device()
    print(f"Starting X-Ray Model Training on device: {device}")

    dataset = MedicalImageDataset(data_dir, transform=get_medical_transforms(is_train=True))
    if len(dataset) == 0:
        print(f"No image samples found in {data_dir}. Please place dataset in class subfolders.")
        return

    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_ds, val_ds = random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

    model = XRayResNet18(num_classes=3, pretrained=True).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-2)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

    best_f1 = 0.0
    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * inputs.size(0)

        scheduler.step()
        epoch_loss = running_loss / max(train_size, 1)

        # Evaluation
        val_metrics = evaluate_model(model, val_loader, device, num_classes=3)
        print(f"Epoch [{epoch+1}/{epochs}] - Loss: {epoch_loss:.4f} - Val Acc: {val_metrics['accuracy']:.4f} - Val F1: {val_metrics['f1_score']:.4f}")

        if val_metrics["f1_score"] >= best_f1:
            best_f1 = val_metrics["f1_score"]
            save_path = save_model_weights(model, "xray")
            print(f"Saved best X-Ray model checkpoint to {save_path}")

    print("X-Ray training complete.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train Chest X-Ray Model")
    parser.add_argument("--data_dir", type=Path, default=Path("dataset/xray"), help="Path to X-Ray dataset directory")
    parser.add_argument("--epochs", type=int, default=10, help="Number of training epochs")
    parser.add_argument("--batch_size", type=int, default=16, help="Batch size")
    parser.add_argument("--lr", type=float, default=1e-4, help="Learning rate")
    args = parser.parse_args()

    train_xray(args.data_dir, args.epochs, args.batch_size, args.lr)
