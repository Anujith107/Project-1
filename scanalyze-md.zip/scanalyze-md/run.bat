@echo off
title ScanalyzeMD Launcher
echo ========================================================
echo               Starting ScanalyzeMD
echo    Explainable Multimodal Medical Imaging Assistant
echo ========================================================
echo.

cd /d "%~dp0"

echo [1/3] Checking and initializing model checkpoints and sample scans...
python backend\generate_samples_and_models.py
echo.

echo [2/3] Starting Backend API Server (FastAPI on http://127.0.0.1:8000)...
start "ScanalyzeMD - Backend API" cmd /k "python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload"

echo [3/3] Starting Frontend Dev Server (Vite on http://localhost:5173)...
cd frontend
start "ScanalyzeMD - Frontend UI" cmd /k "npm.cmd run dev"

echo.
echo ========================================================
echo ScanalyzeMD is launching!
echo Backend API : http://127.0.0.1:8000
echo Swagger Docs: http://127.0.0.1:8000/docs
echo Frontend App: http://localhost:5173
echo ========================================================
echo.
pause
