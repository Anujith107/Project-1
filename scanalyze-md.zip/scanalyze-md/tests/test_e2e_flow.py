import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
import requests
from backend.app.config import SAMPLE_DATA_DIR

BASE_URL = "http://127.0.0.1:8000"

def test_e2e_full_system_flow():
    # 1. Health check
    health_res = requests.get(f"{BASE_URL}/api/health")
    assert health_res.status_code == 200, "Backend health check failed"
    health_data = health_res.json()
    assert health_data["status"] == "healthy"
    print("[PASS] 1. Backend Health Check OK")

    # 2. X-Ray Analysis Flow (Pneumonia / Opacity)
    xray_sample = SAMPLE_DATA_DIR / "xray_opacity.png"
    assert xray_sample.exists()

    with open(xray_sample, "rb") as f:
        up_res = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": ("xray_test.png", f, "image/png")},
            data={"modality": "xray"}
        )
    assert up_res.status_code == 200
    up_data = up_res.json()
    saved_fn = up_data["saved_filename"]
    print("[PASS] 2. Scan Upload OK:", saved_fn)

    # 3. Validate Scan
    val_res = requests.post(
        f"{BASE_URL}/api/validate",
        json={"saved_filename": saved_fn, "modality": "xray"}
    )
    assert val_res.status_code == 200
    val_data = val_res.json()
    assert val_data["valid"] is True
    print("[PASS] 3. Scan Validation OK:", val_data["overall_status"])

    # 4. Analyze Scan
    analyze_res = requests.post(
        f"{BASE_URL}/api/analyze",
        json={"saved_filename": saved_fn, "modality": "xray", "patient_id": "PT-E2E-XRAY"}
    )
    assert analyze_res.status_code == 200
    result = analyze_res.json()["data"]
    assert result["modality"] == "Chest X-Ray"
    assert result["validation_status"] in ["VALID", "WARNING"]
    assert result["severity"] in ["NORMAL", "MODERATE", "CRITICAL"]
    assert result["original_image_url"] is not None
    assert result["gradcam_image_url"] is not None
    print("[PASS] 4. AI Inference & Grad-CAM OK: Severity =", result["severity"], "Confidence =", result["confidence"])

    # Verify Grad-CAM image is actually downloadable from server
    img_res = requests.get(f"{BASE_URL}{result['gradcam_image_url']}")
    assert img_res.status_code == 200
    assert len(img_res.content) > 1000
    print("[PASS] 5. Grad-CAM Overlay Image Served OK (Bytes:", len(img_res.content), ")")

    # 5. Invalid Scan Validation Test (Lateral X-Ray)
    lat_sample = SAMPLE_DATA_DIR / "xray_lateral_invalid.png"
    with open(lat_sample, "rb") as f:
        lat_up = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": ("lateral_test.png", f, "image/png")},
            data={"modality": "xray"}
        )
    assert lat_up.status_code == 200
    lat_fn = lat_up.json()["saved_filename"]

    lat_val = requests.post(
        f"{BASE_URL}/api/validate",
        json={"saved_filename": lat_fn, "modality": "xray"}
    )
    assert lat_val.status_code == 200
    lat_val_data = lat_val.json()
    print("[PASS] 6. Invalid Orientation Test OK (Status:", lat_val_data["overall_status"], "Reason:", lat_val_data["rejection_reason"], ")")

    # 6. CT Analysis Flow (Hemorrhage)
    ct_sample = SAMPLE_DATA_DIR / "ct_hemorrhage.png"
    with open(ct_sample, "rb") as f:
        ct_up = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": ("ct_test.png", f, "image/png")},
            data={"modality": "ct"}
        )
    assert ct_up.status_code == 200
    ct_fn = ct_up.json()["saved_filename"]

    ct_res = requests.post(
        f"{BASE_URL}/api/analyze",
        json={"saved_filename": ct_fn, "modality": "ct", "patient_id": "PT-E2E-CT"}
    )
    assert ct_res.status_code == 200
    assert ct_res.json()["data"]["modality"] == "Computed Tomography (CT)"
    print("[PASS] 7. CT Analysis Flow OK:", ct_res.json()["data"]["severity"])

    # 7. MRI Analysis Flow (Tumor / Hyperintensity)
    mri_sample = SAMPLE_DATA_DIR / "mri_tumor.png"
    with open(mri_sample, "rb") as f:
        mri_up = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": ("mri_test.png", f, "image/png")},
            data={"modality": "mri"}
        )
    assert mri_up.status_code == 200
    mri_fn = mri_up.json()["saved_filename"]

    mri_res = requests.post(
        f"{BASE_URL}/api/analyze",
        json={"saved_filename": mri_fn, "modality": "mri", "patient_id": "PT-E2E-MRI"}
    )
    assert mri_res.status_code == 200
    assert mri_res.json()["data"]["modality"] == "Magnetic Resonance Imaging (MRI)"
    print("[PASS] 8. MRI Analysis Flow OK:", mri_res.json()["data"]["severity"])

    # 8. History and Dashboard Statistics verification
    hist_res = requests.get(f"{BASE_URL}/api/history")
    assert hist_res.status_code == 200
    hist_list = hist_res.json()["data"]
    assert len(hist_list) >= 3
    print(f"[PASS] 9. SQLite History Verified: {len(hist_list)} records retrieved")

    stats_res = requests.get(f"{BASE_URL}/api/stats")
    assert stats_res.status_code == 200
    stats = stats_res.json()["data"]
    assert stats["total_analyses"] >= 3
    assert stats["valid_scans"] >= 3
    print(f"[PASS] 10. Dashboard Stats Verified: Total={stats['total_analyses']}, Valid={stats['valid_scans']}, Abnormal={stats['abnormal_findings']}")

if __name__ == "__main__":
    test_e2e_full_system_flow()
    print("\nALL END-TO-END VERIFICATION STEPS PASSED SUCCESSFULLY!")
