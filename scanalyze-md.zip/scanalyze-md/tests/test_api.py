import pytest
from fastapi.testclient import TestClient
from pathlib import Path
from backend.app.main import app
from backend.app.config import SAMPLE_DATA_DIR
from backend.app.database.connection import init_db

init_db()
client = TestClient(app)

def test_health_endpoint():
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "model_weights" in data

def test_upload_and_analyze_xray_flow():
    # 1. Upload scan
    sample_path = SAMPLE_DATA_DIR / "xray_opacity.png"
    assert sample_path.exists()

    with open(sample_path, "rb") as f:
        upload_resp = client.post(
            "/api/upload",
            files={"file": ("test_xray.png", f, "image/png")},
            data={"modality": "xray"}
        )
    assert upload_resp.status_code == 200
    upload_data = upload_resp.json()
    saved_filename = upload_data["saved_filename"]

    # 2. Validate scan
    val_resp = client.post(
        "/api/validate",
        json={"saved_filename": saved_filename, "modality": "xray"}
    )
    assert val_resp.status_code == 200
    val_data = val_resp.json()
    assert val_data["valid"] is True

    # 3. Analyze scan
    analyze_resp = client.post(
        "/api/analyze",
        json={
            "saved_filename": saved_filename,
            "modality": "xray",
            "patient_id": "TEST-PT-001"
        }
    )
    assert analyze_resp.status_code == 200
    result_data = analyze_resp.json()["data"]
    assert result_data["modality"] == "Chest X-Ray"
    assert result_data["validation_status"] in ["VALID", "WARNING"]
    assert result_data["severity"] in ["NORMAL", "MODERATE", "CRITICAL"]
    assert result_data["original_image_url"] is not None
    assert result_data["gradcam_image_url"] is not None

    scan_id = result_data["id"]

    # 4. History retrieval
    hist_resp = client.get("/api/history")
    assert hist_resp.status_code == 200
    hist_data = hist_resp.json()
    assert hist_data["count"] >= 1

    # 5. Detail retrieval
    detail_resp = client.get(f"/api/result/{scan_id}")
    assert detail_resp.status_code == 200
    assert detail_resp.json()["data"]["id"] == scan_id

def test_dashboard_stats():
    stats_resp = client.get("/api/stats")
    assert stats_resp.status_code == 200
    stats = stats_resp.json()["data"]
    assert "total_analyses" in stats
    assert "valid_scans" in stats
