import pytest
from pathlib import Path
import torch
from backend.app.config import SAMPLE_DATA_DIR, RESULTS_DIR
from backend.app.inference.model_loader import load_model_for_modality, get_device
from backend.app.preprocessing.xray import preprocess_xray
from backend.app.preprocessing.ct import preprocess_ct
from backend.app.preprocessing.mri import preprocess_mri
from backend.app.preprocessing.common import read_scan_file
from backend.app.explainability.gradcam import generate_gradcam_visualizations

def test_xray_model_inference():
    model, meta = load_model_for_modality("xray")
    assert model is not None
    assert meta["model_name"] == "ResNet18-ChestXRay"
    
    sample = SAMPLE_DATA_DIR / "xray_opacity.png"
    rgb, _ = read_scan_file(sample)
    tensor, _ = preprocess_xray(rgb)
    device = get_device()
    
    with torch.no_grad():
        out = model(tensor.to(device))
        assert out.shape == (1, 3)

def test_ct_model_inference():
    model, meta = load_model_for_modality("ct")
    assert model is not None
    
    sample = SAMPLE_DATA_DIR / "ct_hemorrhage.png"
    rgb, _ = read_scan_file(sample)
    tensor, _ = preprocess_ct(rgb)
    device = get_device()
    
    with torch.no_grad():
        out = model(tensor.to(device))
        assert out.shape == (1, 2)

def test_gradcam_generation():
    model, _ = load_model_for_modality("xray")
    sample = SAMPLE_DATA_DIR / "xray_opacity.png"
    rgb, _ = read_scan_file(sample)
    tensor, display_rgb = preprocess_xray(rgb)
    device = get_device()

    out_prefix = RESULTS_DIR / "test_cam"
    res = generate_gradcam_visualizations(
        model=model,
        input_tensor=tensor,
        raw_rgb_image=display_rgb,
        target_category_idx=1,
        output_prefix_path=out_prefix,
        device=device
    )

    assert Path(res["original_image_path"]).exists()
    assert Path(res["gradcam_image_path"]).exists()
