import pytest
from pathlib import Path
import numpy as np
from backend.app.config import SAMPLE_DATA_DIR
from backend.app.validation.file_validator import validate_file_integrity
from backend.app.validation.quality_validator import validate_image_quality
from backend.app.validation.orientation_validator import validate_scan_orientation
from backend.app.validation.modality_validator import validate_modality_compatibility
from backend.app.services.validation_service import run_full_scan_validation
from backend.app.preprocessing.common import read_scan_file

def test_file_validator_valid_png():
    sample = SAMPLE_DATA_DIR / "xray_normal.png"
    assert sample.exists(), f"Missing sample file {sample}"
    result = validate_file_integrity(sample)
    assert result["valid"] is True
    assert result["status"] == "VALID"

def test_file_validator_valid_dicom():
    sample = SAMPLE_DATA_DIR / "xray_normal.dcm"
    assert sample.exists(), f"Missing sample file {sample}"
    result = validate_file_integrity(sample)
    assert result["valid"] is True
    assert result["status"] == "VALID"
    assert result["details"]["is_dicom"] is True

def test_quality_validator_clear_image():
    sample = SAMPLE_DATA_DIR / "xray_normal.png"
    rgb, _ = read_scan_file(sample)
    quality = validate_image_quality(rgb)
    assert quality["valid"] is True
    assert quality["status"] in ["VALID", "WARNING"]
    assert quality["metrics"]["focus_score"] > 10.0

def test_orientation_validator_frontal():
    sample = SAMPLE_DATA_DIR / "xray_normal.png"
    rgb, meta = read_scan_file(sample)
    orient = validate_scan_orientation(rgb, "xray", meta)
    assert orient["valid"] is True
    assert orient["status"] == "VALID"

def test_orientation_validator_lateral_fails():
    sample = SAMPLE_DATA_DIR / "xray_lateral_invalid.png"
    rgb, meta = read_scan_file(sample)
    orient = validate_scan_orientation(rgb, "xray", meta)
    # Severe asymmetry or lateral view detected
    assert orient["status"] in ["INVALID", "WARNING"]

def test_full_validation_service_success():
    sample = SAMPLE_DATA_DIR / "xray_normal.png"
    passed, status, report, img, meta = run_full_scan_validation(sample, "xray")
    assert passed is True
    assert status in ["VALID", "WARNING"]
    assert img is not None
