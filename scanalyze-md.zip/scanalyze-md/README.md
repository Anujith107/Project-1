# ScanalyzeMD

### Explainable Multimodal Medical Imaging Assistant

**ScanalyzeMD** is a complete, runnable research and educational decision-support web application for multimodal medical scan analysis. It supports **Frontal Chest X-Ray, Axial CT, and Brain MRI** imaging modalities with real-time scan validation, modality-specific preprocessing, PyTorch deep learning inference, Grad-CAM explainability, and structured clinical decision-support reporting.

---

## Key Features

- **Multimodal Support**:
  - **Chest X-Ray**: Frontal PA/AP radiograph analysis for opacity / infiltrate detection.
  - **Computed Tomography (CT)**: Axial slice evaluation for acute findings / hemorrhage suspicion.
  - **Magnetic Resonance Imaging (MRI)**: Brain MRI slice analysis for hyperintense lesions and mass effects.
- **Multistage Scan Validation**:
  - **File Integrity**: Verifies format (DICOM, PNG, JPG), readable pixel arrays, and dimensions.
  - **Modality Validation**: Cross-checks user selection against DICOM metadata or pixel characteristics.
  - **Orientation & View**: Frontal AP/PA check with symmetry analysis for chest X-rays (rejects lateral views).
  - **Image Quality**: Real-time focus / blur check (Laplacian variance), contrast (std dev), and extreme brightness detection.
  - *Safety Gate*: Fails gracefully with `INVALID ✕` without continuing to medical inference or hallucinating findings.
- **Explainable AI (Grad-CAM)**:
  - Real gradient-weighted class activation maps computed on the final convolutional layer (`pytorch-grad-cam`).
  - Side-by-side visualization of the original scan alongside the Grad-CAM heatmap overlay.
- **Standardized Medical Output UI**:
  - Exact information hierarchy: `Modality` → `Scan Status` → `Anomaly` → `Severity` (`NORMAL`, `MODERATE`, `CRITICAL`) → `Description` → `Common Associated Symptoms` → `Suggestions` → `Grad-CAM` → `Real Confidence`.
- **Local Persistence & Dashboard**:
  - Local SQLite database tracking all analyses, summary statistics, and searchable historical records.

---

## Technology Stack

- **Frontend**: React 18, Vite, TypeScript, Tailwind CSS, Lucide React, Axios, React Router.
- **Backend**: Python 3.14 / 3.11+, FastAPI, Uvicorn, SQLAlchemy, SQLite, Pydantic, Python-Multipart.
- **AI & Explainability**: PyTorch, Torchvision, OpenCV, Pillow, NumPy, Scikit-Learn, Pydicom, PyTorch-Grad-CAM.

---

## Quick Start (Windows)

### 1. One-Click Batch Startup
Run the bundled batch script from the repository root:
```cmd
run.bat
```

### 2. Manual Startup

#### Backend
```cmd
# Install dependencies
pip install -r backend\requirements.txt

# Generate initial sample data and model weights
python backend\generate_samples_and_models.py

# Start FastAPI server
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
```

#### Frontend
```cmd
cd frontend
npm install
npm run dev
```

Open your browser at `http://localhost:5173`.

---

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Backend status, CUDA availability, model checkpoint discovery |
| `POST` | `/api/upload` | Uploads DICOM/PNG/JPG scan, validates format and detects modality |
| `POST` | `/api/validate` | Executes 4-step scan validation (file, modality, position, quality) |
| `POST` | `/api/analyze` | Executes complete validation, preprocessing, AI inference, Grad-CAM, and persistence |
| `POST` | `/api/gradcam` | Recalculates Grad-CAM activation map for a scan |
| `GET` | `/api/history` | Retrieves paginated and filtered historical scan analyses |
| `GET` | `/api/result/{scan_id}` | Retrieves full structured clinical report for a saved scan |
| `GET` | `/api/stats` | Aggregated dashboard statistics (total analyses, valid scans, abnormal count) |

---

## Medical Disclaimer

> **ScanalyzeMD is a research and educational prototype for medical-image decision support. It is not a medical diagnosis system and has not been clinically validated. All outputs and Grad-CAM visualizations must be reviewed and interpreted by a qualified healthcare professional.**
