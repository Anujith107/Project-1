export type ModalityType = 'xray' | 'ct' | 'mri';

export type ValidationStatus = 'VALID' | 'WARNING' | 'INVALID';

export type SeverityType = 'NORMAL' | 'MODERATE' | 'CRITICAL' | 'Not Determined';

export interface ValidationCheckDetail {
  valid: boolean;
  status: ValidationStatus;
  reason?: string;
  details?: Record<string, any>;
  metrics?: {
    focus_score?: number;
    mean_brightness?: number;
    contrast_std?: number;
    noise_level?: number;
  };
}

export interface ValidationReport {
  overall_status: ValidationStatus;
  passed: boolean;
  rejection_reason?: string | null;
  checks?: {
    file_integrity?: ValidationCheckDetail;
    modality?: ValidationCheckDetail;
    orientation?: ValidationCheckDetail;
    quality?: ValidationCheckDetail;
  };
}

export interface UploadResponse {
  success: boolean;
  filename: string;
  saved_filename: string;
  file_path: string;
  file_size_bytes: number;
  detected_modality: ModalityType;
  dicom_patient_id?: string | null;
  integrity: {
    valid: boolean;
    status: ValidationStatus;
    reason: string;
    details?: Record<string, any>;
  };
}

export interface ScanAnalysisResult {
  id: string;
  patient_id: string;
  created_at: string;
  filename: string;
  file_size_bytes: number;
  modality: string;
  modality_key: ModalityType;
  validation_status: ValidationStatus;
  validation_passed: boolean;
  validation_details?: ValidationReport | null;
  rejection_reason?: string | null;
  anomaly_detected: boolean;
  anomaly_name?: string | null;
  predicted_class_id?: string | null;
  predicted_class_name?: string | null;
  confidence?: number | null;
  confidence_percentage?: number | null;
  severity: SeverityType;
  description?: string | null;
  symptoms?: string | null;
  suggestions?: string | null;
  original_image_url?: string | null;
  gradcam_image_url?: string | null;
  model_name?: string | null;
  is_prototype_model?: boolean;
}

export interface DashboardStats {
  total_analyses: number;
  valid_scans: number;
  abnormal_findings: number;
  recent_analyses_count: number;
  recent_analyses: ScanAnalysisResult[];
  modalities: {
    xray: number;
    ct: number;
    mri: number;
  };
  severities: {
    NORMAL: number;
    MODERATE: number;
    CRITICAL: number;
  };
}
