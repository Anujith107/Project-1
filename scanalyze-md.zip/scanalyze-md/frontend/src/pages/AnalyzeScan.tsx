import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Play,
  RotateCcw,
  AlertTriangle,
  FileSearch,
  History as HistoryIcon
} from 'lucide-react';
import { api } from '../services/api';
import { ModalityType, ValidationReport, ScanAnalysisResult } from '../types/scan';
import { Stepper, PipelineStep } from '../components/Stepper';
import { UploadZone } from '../components/UploadZone';
import { ValidationCard } from '../components/ValidationCard';
import { ReportCard } from '../components/ReportCard';
import { GradCamViewer } from '../components/GradCamViewer';
import { SampleSelector } from '../components/SampleSelector';
import { Disclaimer } from '../components/Disclaimer';

export const AnalyzeScan: React.FC = () => {
  const navigate = useNavigate();

  // Workflow State
  const [currentStep, setCurrentStep] = useState<PipelineStep>('upload');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // File & Modality State
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [modality, setModality] = useState<ModalityType>('xray');
  const [patientId, setPatientId] = useState<string>('');

  // Pipeline Results
  const [validationReport, setValidationReport] = useState<ValidationReport | null>(null);
  const [analysisResult, setAnalysisResult] = useState<ScanAnalysisResult | null>(null);

  // Handle User File Selection
  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    setError(null);
    setAnalysisResult(null);
    setValidationReport(null);

    const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    if (['.png', '.jpg', '.jpeg'].includes(ext)) {
      setPreviewUrl(URL.createObjectURL(file));
    } else {
      setPreviewUrl(null);
    }
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setValidationReport(null);
    setAnalysisResult(null);
    setCurrentStep('upload');
    setError(null);
  };

  // Load Verified Sample from Server
  const handleSelectSample = async (sample: any) => {
    setError(null);
    setIsProcessing(true);
    setModality(sample.modality);
    setAnalysisResult(null);
    setValidationReport(null);

    try {
      const res = await fetch(`/api/samples/${sample.filename}`);
      if (!res.ok) throw new Error('Could not fetch sample scan from server.');
      const blob = await res.blob();
      const file = new File([blob], sample.filename, { type: blob.type || 'image/png' });

      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(blob));
      setCurrentStep('upload');
    } catch (err: any) {
      setError(`Failed to load sample: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // Execute Pipeline (Upload -> Validate -> Preprocess -> Inference -> Grad-CAM)
  const handleRunAnalysis = async () => {
    if (!selectedFile) {
      setError('Please select or upload a scan file first.');
      return;
    }

    try {
      setIsProcessing(true);
      setError(null);

      // Step 1: Upload
      setCurrentStep('upload');
      const uploadData = await api.uploadScan(selectedFile, modality);

      // Step 2: Validate
      setCurrentStep('validate');
      const valResponse = await api.validateScan(uploadData.saved_filename, modality);
      setValidationReport(valResponse.report);

      // If validation is INVALID, halt pipeline and display validation error card
      if (valResponse.overall_status === 'INVALID' || !valResponse.valid) {
        setIsProcessing(false);
        setCurrentStep('result');
        return;
      }

      // Step 3 & 4: Preprocess & Inference
      setCurrentStep('preprocess');
      await new Promise((r) => setTimeout(r, 400));

      setCurrentStep('analyze');
      await new Promise((r) => setTimeout(r, 400));

      // Step 5: Explain (Grad-CAM)
      setCurrentStep('explain');
      const result = await api.analyzeScan(
        uploadData.saved_filename,
        modality,
        patientId.trim() || undefined
      );

      // Step 6: Complete Result
      setAnalysisResult(result);
      setCurrentStep('result');
    } catch (err: any) {
      console.error('Analysis error:', err);
      setError(err.response?.data?.detail || err.message || 'An error occurred during analysis.');
      setCurrentStep('upload');
    } finally {
      setIsProcessing(false);
    }
  };

  const getModalityDisplayName = (mod: ModalityType) => {
    switch (mod) {
      case 'xray':
        return 'Chest X-Ray';
      case 'ct':
        return 'Computed Tomography (CT)';
      case 'mri':
        return 'Magnetic Resonance Imaging (MRI)';
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Analyze Medical Scan
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Frontal Chest X-Ray • Axial CT • Brain MRI Pipeline
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {analysisResult && (
            <button
              onClick={handleRemoveFile}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>New Analysis</span>
            </button>
          )}
        </div>
      </div>

      {/* Dynamic Progress Stepper */}
      <Stepper currentStep={currentStep} isProcessing={isProcessing} />

      {/* Main Analysis Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Upload & Configuration Controls */}
        <div className="lg:col-span-5 space-y-4">
          
          <UploadZone
            onFileSelect={handleFileSelect}
            selectedFile={selectedFile}
            previewUrl={previewUrl}
            onRemoveFile={handleRemoveFile}
            modality={modality}
            onModalityChange={setModality}
            isUploading={isProcessing}
          />

          {/* Optional Patient ID Field */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Patient Identifier (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. PT-2026-0042 (Auto-generated if blank)"
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              disabled={isProcessing}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-sky-500 bg-slate-50/50"
            />
          </div>

          {/* Quick Test Dataset Samples */}
          <SampleSelector onSelectSample={handleSelectSample} disabled={isProcessing} />

          {/* Run Analysis CTA Button */}
          {selectedFile && !analysisResult && (
            <button
              type="button"
              onClick={handleRunAnalysis}
              disabled={isProcessing}
              className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl bg-gradient-to-r from-sky-700 to-sky-600 hover:from-sky-600 hover:to-sky-500 text-white font-bold text-sm shadow-md shadow-sky-600/30 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50"
            >
              <Play className={`w-4 h-4 fill-current ${isProcessing ? 'animate-spin' : ''}`} />
              <span>{isProcessing ? 'Running AI Pipeline...' : 'Run ScanalyzeMD Pipeline'}</span>
            </button>
          )}

          {/* Global Error Notice */}
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

        </div>

        {/* Right Column: Validation & Results Output */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Validation Card (Visible once validated) */}
          {validationReport && (
            <ValidationCard
              report={validationReport}
              modalityTitle={getModalityDisplayName(modality)}
            />
          )}

          {/* Case 1: Validation Failed - Show Invalid Summary Notice */}
          {validationReport && validationReport.overall_status === 'INVALID' && (
            <div className="medical-card border-2 border-rose-600 overflow-hidden shadow-md">
              <div className="bg-rose-900 text-white text-center py-3 px-4 font-bold text-xs uppercase tracking-wider">
                SCAN ANALYSIS — VALIDATION REJECTED
              </div>
              <div className="p-6 space-y-4 bg-white text-sm">
                <div className="flex justify-between items-center pb-3 border-b border-slate-200">
                  <span className="text-slate-500 font-medium">Modality</span>
                  <span className="font-semibold text-slate-900">{getModalityDisplayName(modality)}</span>
                </div>
                <div className="flex justify-between items-center pb-3 border-b border-slate-200">
                  <span className="text-slate-500 font-medium">Scan Status</span>
                  <span className="font-bold text-rose-700">Invalid ✕</span>
                </div>
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-lg text-xs space-y-1">
                  <p className="font-bold text-rose-900">Reason</p>
                  <p className="text-rose-800">{validationReport.rejection_reason || 'Scan failed positioning or quality validation criteria.'}</p>
                </div>
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
                  <p className="font-bold text-slate-800">Action Required</p>
                  <p className="text-slate-600">Please upload a supported frontal scan/view meeting diagnostic image resolution requirements.</p>
                </div>
                <p className="text-[11px] text-slate-400 italic">
                  *Medical inference and Grad-CAM were not executed because the scan did not pass initial validation.
                </p>
              </div>
            </div>
          )}

          {/* Case 2: Validation Succeeded - Primary Result Card & Grad-CAM */}
          {analysisResult && (
            <div className="space-y-6">
              
              {/* EXACT MAIN OUTPUT UI: SCAN ANALYSIS REPORT CARD */}
              <ReportCard data={analysisResult} />

              {/* GRAD-CAM REAL VISUALIZATION (Side-by-side) */}
              <GradCamViewer
                originalImageUrl={analysisResult.original_image_url}
                gradcamImageUrl={analysisResult.gradcam_image_url}
                confidence={analysisResult.confidence}
                confidencePercentage={analysisResult.confidence_percentage}
                modelName={analysisResult.model_name}
                isPrototypeModel={analysisResult.is_prototype_model}
              />

              {/* Post-Analysis Navigation / History CTA */}
              <div className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
                <span className="text-xs text-slate-500">
                  Analysis record saved to local database (ID: <span className="font-mono text-slate-800 font-semibold">{analysisResult.id.slice(0, 8)}</span>)
                </span>
                <button
                  onClick={() => navigate('/history')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 text-xs font-semibold transition-colors"
                >
                  <HistoryIcon className="w-3.5 h-3.5" />
                  <span>View in History</span>
                </button>
              </div>

            </div>
          )}

          {/* Empty Placeholder when no analysis running */}
          {!validationReport && !analysisResult && (
            <div className="medical-card p-12 text-center text-slate-400 space-y-3">
              <FileSearch className="w-12 h-12 mx-auto text-slate-300 stroke-[1.5]" />
              <div>
                <h3 className="text-sm font-semibold text-slate-700">
                  Ready for Medical Scan Analysis
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Upload an X-Ray, CT, or MRI image or click one of the quick test samples on the left to begin validation and explainable AI inference.
                </p>
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Medical Disclaimer */}
      <Disclaimer />

    </div>
  );
};
