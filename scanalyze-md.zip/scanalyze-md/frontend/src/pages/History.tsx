import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  History as HistoryIcon,
  Search,
  ChevronRight,
  RefreshCw,
  FileText
} from 'lucide-react';
import { api } from '../services/api';
import { ScanAnalysisResult } from '../types/scan';
import { Disclaimer } from '../components/Disclaimer';

export const History: React.FC = () => {
  const navigate = useNavigate();
  const [scans, setScans] = useState<ScanAnalysisResult[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [modalityFilter, setModalityFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const fetchHistory = async () => {
    try {
      setLoading(true);
      setError(null);
      const params: any = {};
      if (modalityFilter !== 'all') params.modality = modalityFilter;
      if (severityFilter !== 'all') params.severity = severityFilter;

      const res = await api.getHistory(params);
      setScans(res.data || []);
    } catch (err: any) {
      console.error('History fetch error:', err);
      setError('Unable to load history from database.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [modalityFilter, severityFilter]);

  const filteredScans = scans.filter((scan) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      scan.patient_id.toLowerCase().includes(q) ||
      scan.filename.toLowerCase().includes(q) ||
      scan.modality.toLowerCase().includes(q) ||
      (scan.predicted_class_name && scan.predicted_class_name.toLowerCase().includes(q))
    );
  });

  const formatDate = (isoString?: string) => {
    if (!isoString) return 'N/A';
    const d = new Date(isoString);
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'NORMAL':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
            NORMAL
          </span>
        );
      case 'MODERATE':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">
            MODERATE
          </span>
        );
      case 'CRITICAL':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-200">
            CRITICAL
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            {sev || 'N/A'}
          </span>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            <HistoryIcon className="w-6 h-6 text-sky-600" />
            Analysis History
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Locally persisted scan analyses, clinical reports, and Grad-CAM activations
          </p>
        </div>

        <button
          onClick={fetchHistory}
          disabled={loading}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors shadow-xs"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Records</span>
        </button>
      </div>

      {/* Filter Controls Bar */}
      <div className="medical-card p-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by Patient ID, Finding, or File..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-sky-500 bg-slate-50/50"
          />
        </div>

        {/* Modality Filter */}
        <div>
          <select
            value={modalityFilter}
            onChange={(e) => setModalityFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-sky-500 bg-slate-50/50 text-slate-700"
          >
            <option value="all">All Modalities (X-Ray, CT, MRI)</option>
            <option value="xray">Chest X-Ray</option>
            <option value="ct">Computed Tomography (CT)</option>
            <option value="mri">Magnetic Resonance Imaging (MRI)</option>
          </select>
        </div>

        {/* Severity Filter */}
        <div>
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-sky-500 bg-slate-50/50 text-slate-700"
          >
            <option value="all">All Severities</option>
            <option value="NORMAL">Normal</option>
            <option value="MODERATE">Moderate</option>
            <option value="CRITICAL">Critical</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="medical-card overflow-hidden">
        {loading ? (
          <div className="p-16 text-center text-slate-400 text-sm">
            Loading analysis history...
          </div>
        ) : error ? (
          <div className="p-8 text-center text-rose-600 text-sm">
            {error}
          </div>
        ) : filteredScans.length === 0 ? (
          <div className="p-16 text-center text-slate-400 space-y-2">
            <FileText className="w-10 h-10 mx-auto text-slate-300" />
            <p className="text-sm font-semibold text-slate-700">No matching scan analyses found</p>
            <p className="text-xs text-slate-500">Try adjusting your filters or analyze a new scan.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider border-b border-slate-200 font-semibold">
                <tr>
                  <th className="py-3.5 px-4">Patient ID</th>
                  <th className="py-3.5 px-4">Date & Time</th>
                  <th className="py-3.5 px-4">Modality</th>
                  <th className="py-3.5 px-4">Finding</th>
                  <th className="py-3.5 px-4">Severity</th>
                  <th className="py-3.5 px-4">Confidence</th>
                  <th className="py-3.5 px-4 text-right">View Report</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredScans.map((scan) => (
                  <tr
                    key={scan.id}
                    onClick={() => navigate(`/result/${scan.id}`)}
                    className="hover:bg-sky-50/40 cursor-pointer transition-colors group"
                  >
                    <td className="py-4 px-4 font-mono font-semibold text-slate-900 text-xs">
                      {scan.patient_id || scan.id.slice(0, 8)}
                    </td>
                    <td className="py-4 px-4 text-slate-500 text-xs whitespace-nowrap">
                      {formatDate(scan.created_at)}
                    </td>
                    <td className="py-4 px-4 text-slate-800 font-medium">
                      {scan.modality}
                    </td>
                    <td className="py-4 px-4">
                      {scan.anomaly_detected ? (
                        <span className="font-semibold text-rose-700">
                          {scan.predicted_class_name || scan.anomaly_name}
                        </span>
                      ) : (
                        <span className="text-emerald-700 font-medium">
                          {scan.validation_passed ? 'Normal' : 'Validation Rejected'}
                        </span>
                      )}
                    </td>
                    <td className="py-4 px-4">
                      {getSeverityBadge(scan.severity)}
                    </td>
                    <td className="py-4 px-4 font-mono text-xs text-slate-600">
                      {scan.confidence_percentage ? `${scan.confidence_percentage}%` : 'N/A'}
                    </td>
                    <td className="py-4 px-4 text-right">
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-sky-600 inline transition-transform group-hover:translate-x-1" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Disclaimer />

    </div>
  );
};
