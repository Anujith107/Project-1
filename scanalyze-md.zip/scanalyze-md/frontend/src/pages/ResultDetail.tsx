import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Printer, RotateCcw, AlertCircle } from 'lucide-react';
import { api } from '../services/api';
import { ScanAnalysisResult } from '../types/scan';
import { ReportCard } from '../components/ReportCard';
import { GradCamViewer } from '../components/GradCamViewer';
import { ValidationCard } from '../components/ValidationCard';
import { Disclaimer } from '../components/Disclaimer';

export const ResultDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [data, setData] = useState<ScanAnalysisResult | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    api.getResultById(id)
      .then((res) => setData(res))
      .catch((err) => {
        console.error('Failed to load result:', err);
        setError('Scan record not found in local database.');
      })
      .finally(() => setLoading(false));
  }, [id]);

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center text-slate-500 text-sm">
        Retrieving scan report from database...
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center">
          <AlertCircle className="w-6 h-6" />
        </div>
        <h2 className="text-lg font-bold text-slate-800">Record Not Found</h2>
        <p className="text-xs text-slate-500">{error || 'Unable to locate the specified scan report.'}</p>
        <Link
          to="/history"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-sky-600 text-white text-xs font-semibold hover:bg-sky-500"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to History
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <button
          onClick={() => navigate('/history')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to History</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-colors shadow-xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>

          <Link
            to="/analyze"
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold transition-colors shadow-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Analyze Another Scan</span>
          </Link>
        </div>
      </div>

      {/* Validation Information (If available) */}
      {data.validation_details && (
        <ValidationCard
          report={data.validation_details}
          modalityTitle={data.modality}
        />
      )}

      {/* EXACT MAIN OUTPUT UI: SCAN ANALYSIS CARD */}
      <ReportCard data={data} />

      {/* GRAD-CAM VISUALIZATION (Side-by-side) */}
      {data.validation_passed && (
        <GradCamViewer
          originalImageUrl={data.original_image_url}
          gradcamImageUrl={data.gradcam_image_url}
          confidence={data.confidence}
          confidencePercentage={data.confidence_percentage}
          modelName={data.model_name}
          isPrototypeModel={data.is_prototype_model}
        />
      )}

      {/* Disclaimer */}
      <Disclaimer />

    </div>
  );
};
