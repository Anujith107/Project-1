import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  FilePlus,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  RefreshCw,
  Layers,
  ChevronRight
} from 'lucide-react';
import { api } from '../services/api';
import { DashboardStats } from '../types/scan';
import { StatsCard } from '../components/StatsCard';
import { Disclaimer } from '../components/Disclaimer';

export const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStats = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getDashboardStats();
      setStats(data);
    } catch (err: any) {
      console.error('Failed to load dashboard stats:', err);
      setError('Unable to connect to database. Ensure the backend server is running.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const formatDate = (isoString?: string) => {
    if (!isoString) return 'N/A';
    const d = new Date(isoString);
    return d.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'NORMAL':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800">
            NORMAL
          </span>
        );
      case 'MODERATE':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800">
            MODERATE
          </span>
        );
      case 'CRITICAL':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-rose-100 text-rose-800">
            CRITICAL
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-700">
            {sev || 'N/A'}
          </span>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Hero Banner with CTA */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-sky-500/20 text-sky-300 border border-sky-400/30 uppercase tracking-wider">
              Research Prototype v1.0
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            Scanalyze<span className="text-sky-400">MD</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base font-normal mt-1 max-w-2xl">
            Explainable Multimodal Medical Imaging Assistant for X-Ray, CT, and MRI decision support.
          </p>
        </div>

        <Link
          to="/analyze"
          className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm shadow-lg shadow-sky-600/30 transition-all hover:scale-[1.02] active:scale-[0.98] flex-shrink-0"
        >
          <FilePlus className="w-5 h-5" />
          <span>+ Analyze New Scan</span>
        </Link>
      </div>

      {/* Analytics Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Analyses"
          value={loading ? '...' : stats?.total_analyses ?? 0}
          subtitle="Processed scans in SQLite"
          icon={Layers}
          variant="blue"
        />

        <StatsCard
          title="Valid Scans"
          value={loading ? '...' : stats?.valid_scans ?? 0}
          subtitle="Passed position & quality checks"
          icon={CheckCircle2}
          variant="emerald"
        />

        <StatsCard
          title="Abnormal Findings"
          value={loading ? '...' : stats?.abnormal_findings ?? 0}
          subtitle="Anomalies identified by AI"
          icon={AlertTriangle}
          variant="amber"
        />

        <StatsCard
          title="Recent Analyses"
          value={loading ? '...' : stats?.recent_analyses_count ?? 0}
          subtitle="Latest records"
          icon={Clock}
          variant="indigo"
        />
      </div>

      {/* Recent Analyses Table */}
      <div className="medical-card overflow-hidden">
        <div className="p-5 border-b border-slate-200/80 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Recent Analyses
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Real-time records from local database
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchStats}
              disabled={loading}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              title="Refresh Stats"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <Link
              to="/history"
              className="text-xs font-semibold text-sky-700 hover:text-sky-800 flex items-center gap-1"
            >
              <span>View All History</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        {/* Table Content */}
        {loading ? (
          <div className="p-12 text-center text-slate-400 text-sm">
            Loading recent analyses...
          </div>
        ) : error ? (
          <div className="p-8 text-center text-rose-600 text-sm">
            {error}
          </div>
        ) : !stats?.recent_analyses || stats.recent_analyses.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <p className="text-slate-500 text-sm">No medical scans analyzed yet.</p>
            <Link
              to="/analyze"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-sky-600 text-white text-xs font-semibold hover:bg-sky-500"
            >
              <FilePlus className="w-4 h-4" />
              Analyze First Scan
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider border-b border-slate-200 font-semibold">
                <tr>
                  <th className="py-3 px-4">Patient / Scan ID</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Modality</th>
                  <th className="py-3 px-4">Finding</th>
                  <th className="py-3 px-4">Severity</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {stats.recent_analyses.map((scan) => (
                  <tr
                    key={scan.id}
                    onClick={() => navigate(`/result/${scan.id}`)}
                    className="hover:bg-sky-50/40 cursor-pointer transition-colors group"
                  >
                    <td className="py-3.5 px-4 font-mono font-medium text-slate-900 text-xs">
                      {scan.patient_id || scan.id.slice(0, 8)}
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 text-xs">
                      {formatDate(scan.created_at)}
                    </td>
                    <td className="py-3.5 px-4 text-slate-800 font-medium">
                      {scan.modality}
                    </td>
                    <td className="py-3.5 px-4">
                      {scan.anomaly_detected ? (
                        <span className="font-semibold text-rose-700">
                          {scan.predicted_class_name || scan.anomaly_name}
                        </span>
                      ) : (
                        <span className="text-emerald-700 font-medium">
                          {scan.validation_passed ? 'Normal' : 'Validation Rejected'}
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      {getSeverityBadge(scan.severity)}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-sky-600 inline transition-transform group-hover:translate-x-0.5" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Global Medical Disclaimer */}
      <Disclaimer />

    </div>
  );
};
