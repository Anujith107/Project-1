import axios from 'axios';
import {
  UploadResponse,
  ScanAnalysisResult,
  DashboardStats,
  ModalityType,
  ValidationReport
} from '../types/scan';

const API_BASE_URL = import.meta.env.VITE_API_URL || '';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
});

export const api = {
  // Health
  checkHealth: async () => {
    const res = await apiClient.get('/api/health');
    return res.data;
  },

  // Upload Scan
  uploadScan: async (file: File, modality?: ModalityType): Promise<UploadResponse> => {
    const formData = new FormData();
    formData.append('file', file);
    if (modality) {
      formData.append('modality', modality);
    }
    const res = await apiClient.post<UploadResponse>('/api/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },

  // Validate Scan
  validateScan: async (savedFilename: string, modality: ModalityType): Promise<{
    success: boolean;
    valid: boolean;
    overall_status: 'VALID' | 'WARNING' | 'INVALID';
    rejection_reason?: string | null;
    report: ValidationReport;
  }> => {
    const res = await apiClient.post('/api/validate', {
      saved_filename: savedFilename,
      modality,
    });
    return res.data;
  },

  // Analyze Scan
  analyzeScan: async (
    savedFilename: string,
    modality: ModalityType,
    patientId?: string
  ): Promise<ScanAnalysisResult> => {
    const res = await apiClient.post<{ success: boolean; data: ScanAnalysisResult }>('/api/analyze', {
      saved_filename: savedFilename,
      modality,
      patient_id: patientId,
    });
    return res.data.data;
  },

  // Recalculate Grad-CAM
  recalculateGradCam: async (scanId: string, targetClassIdx?: number) => {
    const res = await apiClient.post('/api/gradcam', {
      scan_id: scanId,
      target_class_idx: targetClassIdx,
    });
    return res.data;
  },

  // History
  getHistory: async (params?: {
    skip?: number;
    limit?: number;
    modality?: string;
    severity?: string;
  }): Promise<{ success: boolean; count: number; data: ScanAnalysisResult[] }> => {
    const res = await apiClient.get('/api/history', { params });
    return res.data;
  },

  // Get Result by ID
  getResultById: async (scanId: string): Promise<ScanAnalysisResult> => {
    const res = await apiClient.get<{ success: boolean; data: ScanAnalysisResult }>(`/api/result/${scanId}`);
    return res.data.data;
  },

  // Dashboard Stats
  getDashboardStats: async (): Promise<DashboardStats> => {
    const res = await apiClient.get<{ success: boolean; data: DashboardStats }>('/api/stats');
    return res.data.data;
  },
};
