import React, { useState } from 'react';
import { Layers, ZoomIn } from 'lucide-react';

interface GradCamViewerProps {
  originalImageUrl?: string | null;
  gradcamImageUrl?: string | null;
  confidence?: number | null;
  confidencePercentage?: number | null;
  modelName?: string | null;
  isPrototypeModel?: boolean;
}

export const GradCamViewer: React.FC<GradCamViewerProps> = ({
  originalImageUrl,
  gradcamImageUrl,
  confidence,
  confidencePercentage,
  modelName,
  isPrototypeModel,
}) => {
  const [zoomImage, setZoomImage] = useState<string | null>(null);

  if (!originalImageUrl && !gradcamImageUrl) {
    return null;
  }

  const formattedConfidence = confidencePercentage !== undefined && confidencePercentage !== null
    ? `${confidencePercentage}%`
    : confidence !== undefined && confidence !== null
    ? `${(confidence * 100).toFixed(1)}%`
    : 'N/A';

  return (
    <div className="space-y-4">
      
      {/* AI Explanation Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm sm:text-base font-bold tracking-wider text-slate-900 uppercase flex items-center gap-2">
            <Layers className="w-5 h-5 text-sky-600" />
            AI EXPLANATION (Grad-CAM)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Visual saliency activation map generated from final convolutional layer
          </p>
        </div>

        {modelName && (
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono px-2.5 py-1 rounded bg-slate-100 text-slate-600 border border-slate-200">
              {modelName}
            </span>
            {isPrototypeModel && (
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                Prototype Model
              </span>
            )}
          </div>
        )}
      </div>

      {/* Side-by-Side Images */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Original Scan */}
        <div className="medical-card overflow-hidden bg-slate-950 flex flex-col">
          <div className="bg-slate-900 px-4 py-2.5 flex items-center justify-between border-b border-slate-800">
            <span className="text-xs font-bold text-slate-200 tracking-wider uppercase">
              ORIGINAL SCAN
            </span>
            {originalImageUrl && (
              <button
                type="button"
                onClick={() => setZoomImage(originalImageUrl)}
                className="text-slate-400 hover:text-white transition-colors"
                title="Zoom image"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            )}
          </div>
          <div className="p-3 flex items-center justify-center bg-black min-h-[320px]">
            {originalImageUrl ? (
              <img
                src={originalImageUrl}
                alt="Original Medical Scan"
                className="max-h-[380px] w-auto object-contain rounded cursor-pointer hover:opacity-95 transition-opacity"
                onClick={() => setZoomImage(originalImageUrl)}
              />
            ) : (
              <span className="text-xs text-slate-500">Original image unavailable</span>
            )}
          </div>
        </div>

        {/* Grad-CAM Heatmap */}
        <div className="medical-card overflow-hidden bg-slate-950 flex flex-col">
          <div className="bg-slate-900 px-4 py-2.5 flex items-center justify-between border-b border-slate-800">
            <span className="text-xs font-bold text-sky-400 tracking-wider uppercase flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
              GRAD-CAM ACTIVATION
            </span>
            {gradcamImageUrl && (
              <button
                type="button"
                onClick={() => setZoomImage(gradcamImageUrl)}
                className="text-slate-400 hover:text-white transition-colors"
                title="Zoom Grad-CAM"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            )}
          </div>
          <div className="p-3 flex items-center justify-center bg-black min-h-[320px]">
            {gradcamImageUrl ? (
              <img
                src={gradcamImageUrl}
                alt="Grad-CAM Visualization"
                className="max-h-[380px] w-auto object-contain rounded cursor-pointer hover:opacity-95 transition-opacity"
                onClick={() => setZoomImage(gradcamImageUrl)}
              />
            ) : (
              <span className="text-xs text-slate-500">Grad-CAM visualization unavailable</span>
            )}
          </div>
        </div>

      </div>

      {/* Grad-CAM Explanation Note */}
      <div className="p-3.5 bg-slate-100/90 border border-slate-200 rounded-lg text-xs text-slate-700 leading-relaxed">
        <p>
          <strong className="text-slate-900">Highlighted Region:</strong> The highlighted area represents regions that influenced the model prediction.
        </p>
      </div>

      {/* Model Confidence Card */}
      {confidence !== null && confidence !== undefined && (
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-700 flex items-center justify-center font-bold text-xs">
              AI
            </div>
            <div>
              <span className="text-xs text-slate-500 font-medium block">Model Prediction Confidence</span>
              <span className="text-base font-bold text-slate-900">
                Model Confidence: {formattedConfidence}
              </span>
            </div>
          </div>

          <div className="w-full sm:w-48 bg-slate-100 rounded-full h-2.5 overflow-hidden">
            <div
              className="bg-gradient-to-r from-sky-500 to-sky-700 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, (confidence || 0) * 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* Modal Zoom Viewer */}
      {zoomImage && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setZoomImage(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <img
              src={zoomImage}
              alt="Enlarged Scan"
              className="max-h-[85vh] max-w-full rounded-lg shadow-2xl"
            />
            <p className="text-center text-xs text-slate-300 mt-2">Click anywhere to close</p>
          </div>
        </div>
      )}

    </div>
  );
};
