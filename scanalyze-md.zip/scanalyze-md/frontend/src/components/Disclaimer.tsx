import React from 'react';
import { AlertCircle, Lock } from 'lucide-react';

export const Disclaimer: React.FC = () => {
  return (
    <div className="space-y-3 pt-6 border-t border-slate-200 mt-8">
      {/* Medical Disclaimer */}
      <div className="p-4 bg-amber-50/80 border border-amber-200/90 rounded-xl flex items-start gap-3 text-xs text-amber-900 leading-relaxed shadow-xs">
        <AlertCircle className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
        <div>
          <p className="font-bold uppercase tracking-wider text-amber-900 mb-0.5">
            Research & Educational Prototype Disclaimer
          </p>
          <p>
            <strong>ScanalyzeMD</strong> is a research and educational prototype for medical-image decision support. It is not a medical diagnosis system and has not been clinically validated. All outputs and visualizations must be interpreted and verified by a qualified healthcare professional.
          </p>
        </div>
      </div>

      {/* Local Privacy Guarantee */}
      <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg flex items-center justify-between gap-3 text-[11px] text-slate-600">
        <div className="flex items-center gap-2">
          <Lock className="w-4 h-4 text-slate-500" />
          <span>
            <strong>Local Processing:</strong> Uploaded medical scans are processed locally in this prototype. Avoid uploading personally identifiable patient information.
          </span>
        </div>
        <span className="font-mono text-slate-400 hidden sm:inline">Local SQLite & Offline PyTorch Engine</span>
      </div>
    </div>
  );
};
