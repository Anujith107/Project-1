import React from 'react';
import { Sparkles, AlertTriangle } from 'lucide-react';
import { ModalityType } from '../types/scan';

interface SampleItem {
  id: string;
  label: string;
  category: string;
  filename: string;
  modality: ModalityType;
  expectedResult: string;
  isInvalid?: boolean;
}

const SAMPLES: SampleItem[] = [
  {
    id: 'xray-opacity',
    label: 'Chest X-Ray (Pneumonia/Opacity)',
    category: 'Chest X-Ray',
    filename: 'xray_opacity.png',
    modality: 'xray',
    expectedResult: 'Focal Opacity / Moderate',
  },
  {
    id: 'xray-normal',
    label: 'Chest X-Ray (Normal)',
    category: 'Chest X-Ray',
    filename: 'xray_normal.png',
    modality: 'xray',
    expectedResult: 'Normal / Normal',
  },
  {
    id: 'ct-bleed',
    label: 'Brain CT (Acute Lesion / Bleed)',
    category: 'CT Scan',
    filename: 'ct_hemorrhage.png',
    modality: 'ct',
    expectedResult: 'Acute Finding / Critical',
  },
  {
    id: 'ct-norm',
    label: 'Brain CT (Normal)',
    category: 'CT Scan',
    filename: 'ct_normal.png',
    modality: 'ct',
    expectedResult: 'Normal CT / Normal',
  },
  {
    id: 'mri-tumor',
    label: 'Brain MRI (Hyperintense Lesion)',
    category: 'MRI Scan',
    filename: 'mri_tumor.png',
    modality: 'mri',
    expectedResult: 'Mass Suspicion / Critical',
  },
  {
    id: 'mri-norm',
    label: 'Brain MRI (Normal)',
    category: 'MRI Scan',
    filename: 'mri_normal.png',
    modality: 'mri',
    expectedResult: 'Normal MRI / Normal',
  },
  {
    id: 'xray-lateral',
    label: 'Lateral X-Ray (Invalid Position)',
    category: 'Validation Test',
    filename: 'xray_lateral_invalid.png',
    modality: 'xray',
    expectedResult: 'Validation Rejected (Lateral)',
    isInvalid: true,
  },
  {
    id: 'blurry-scan',
    label: 'Severely Blurry Scan (Quality Rejection)',
    category: 'Validation Test',
    filename: 'blurry_invalid.png',
    modality: 'xray',
    expectedResult: 'Validation Rejected (Blur)',
    isInvalid: true,
  },
];

interface SampleSelectorProps {
  onSelectSample: (sample: SampleItem) => void;
  disabled?: boolean;
}

export const SampleSelector: React.FC<SampleSelectorProps> = ({ onSelectSample, disabled }) => {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-sky-600" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
            Quick Test Samples
          </h4>
        </div>
        <span className="text-[11px] text-slate-400 font-medium">Click to load verified dataset scan</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
        {SAMPLES.map((sample) => (
          <button
            key={sample.id}
            type="button"
            disabled={disabled}
            onClick={() => onSelectSample(sample)}
            className={`p-2.5 rounded-lg border text-left transition-all group flex flex-col justify-between ${
              sample.isInvalid
                ? 'bg-rose-50/40 border-rose-200/80 hover:bg-rose-50 hover:border-rose-300'
                : 'bg-slate-50/70 border-slate-200 hover:bg-sky-50/60 hover:border-sky-300'
            }`}
          >
            <div>
              <div className="flex items-center justify-between text-[10px] font-semibold uppercase tracking-wider mb-1">
                <span className={sample.isInvalid ? 'text-rose-700' : 'text-sky-700'}>
                  {sample.category}
                </span>
                {sample.isInvalid && (
                  <span className="flex items-center gap-0.5 text-rose-600 font-bold">
                    <AlertTriangle className="w-3 h-3" /> Test Rejection
                  </span>
                )}
              </div>
              <p className="text-xs font-semibold text-slate-800 line-clamp-1 group-hover:text-sky-900">
                {sample.label}
              </p>
            </div>
            <p className="text-[11px] text-slate-500 mt-1.5 font-mono">
              Target: {sample.expectedResult}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
};
