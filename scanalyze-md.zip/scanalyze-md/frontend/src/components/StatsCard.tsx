import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  variant?: 'blue' | 'emerald' | 'amber' | 'indigo';
}

export const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  variant = 'blue',
}) => {
  const getColors = () => {
    switch (variant) {
      case 'emerald':
        return {
          bg: 'bg-emerald-50 text-emerald-700',
          border: 'hover:border-emerald-300',
          indicator: 'bg-emerald-500',
        };
      case 'amber':
        return {
          bg: 'bg-amber-50 text-amber-700',
          border: 'hover:border-amber-300',
          indicator: 'bg-amber-500',
        };
      case 'indigo':
        return {
          bg: 'bg-indigo-50 text-indigo-700',
          border: 'hover:border-indigo-300',
          indicator: 'bg-indigo-500',
        };
      case 'blue':
      default:
        return {
          bg: 'bg-sky-50 text-sky-700',
          border: 'hover:border-sky-300',
          indicator: 'bg-sky-500',
        };
    }
  };

  const colors = getColors();

  return (
    <div className={`medical-card p-5 medical-card-hover ${colors.border}`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            {title}
          </p>
          <p className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 mt-1">
            {value}
          </p>
          {subtitle && (
            <p className="text-xs text-slate-500 mt-1">
              {subtitle}
            </p>
          )}
        </div>
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${colors.bg} shadow-xs`}>
          <Icon className="w-6 h-6 stroke-[2]" />
        </div>
      </div>
    </div>
  );
};
