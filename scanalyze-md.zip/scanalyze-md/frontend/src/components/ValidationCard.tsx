import React from 'react';
import { CheckCircle2, AlertTriangle, XCircle, Shield } from 'lucide-react';
import { ValidationReport, ValidationStatus } from '../types/scan';

interface ValidationCardProps {
  report: ValidationReport;
  modalityTitle: string;
}

export const ValidationCard: React.FC<ValidationCardProps> = ({ report, modalityTitle }) => {
  const { overall_status, checks, rejection_reason } = report;

  const getStatusBadge = (status?: ValidationStatus) => {
    switch (status) {
      case 'VALID':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5" /> Valid ✓
          </span>
        );
      case 'WARNING':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <AlertTriangle className="w-3.5 h-3.5" /> Warning ⚠
          </span>
        );
      case 'INVALID':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <XCircle className="w-3.5 h-3.5" /> Invalid ✕
          </span>
        );
    }
  };

  const getStatusColorClass = () => {
    if (overall_status === 'VALID') return 'border-emerald-200 bg-emerald-50/20';
    if (overall_status === 'WARNING') return 'border-amber-200 bg-amber-50/20';
    return 'border-rose-200 bg-rose-50/20';
  };

  return (
    <div className={`medical-card overflow-hidden border ${getStatusColorClass()} shadow-sm`}>
      {/* Header */}
      <div className="bg-slate-900 px-5 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-2 text-white">
          <Shield className="w-4 h-4 text-sky-400" />
          <span className="font-bold text-xs uppercase tracking-wider">Scan Validation</span>
        </div>
        <div>{getStatusBadge(overall_status)}</div>
      </div>

      {/* Body */}
      <div className="p-5 space-y-4 text-sm">
        
        {/* Key Values Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-3 border-b border-slate-200/80">
          <div className="flex justify-between items-center py-1">
            <span className="text-slate-500 font-medium">Modality:</span>
            <span className="font-semibold text-slate-800">{modalityTitle}</span>
          </div>

          <div className="flex justify-between items-center py-1">
            <span className="text-slate-500 font-medium">Position / View:</span>
            <span>{getStatusBadge(checks?.orientation?.status)}</span>
          </div>

          <div className="flex justify-between items-center py-1">
            <span className="text-slate-500 font-medium">Image Quality:</span>
            <span>{getStatusBadge(checks?.quality?.status)}</span>
          </div>

          <div className="flex justify-between items-center py-1">
            <span className="text-slate-500 font-medium">File Integrity:</span>
            <span>{getStatusBadge(checks?.file_integrity?.status)}</span>
          </div>
        </div>

        {/* Detailed Status or Rejection Box */}
        {overall_status === 'INVALID' ? (
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-lg">
            <p className="text-xs font-bold text-rose-800 uppercase tracking-wide mb-1">
              Validation Failed
            </p>
            <p className="text-xs text-rose-700 font-medium mb-2">
              Reason: {rejection_reason || 'Scan failed positioning or quality criteria.'}
            </p>
            <p className="text-xs text-slate-600">
              Please upload a supported frontal scan/view meeting diagnostic image quality requirements.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {checks?.quality?.metrics && (
              <div className="grid grid-cols-3 gap-2 p-2.5 bg-slate-50 rounded-lg text-center text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px]">Focus Score</span>
                  <span className="font-semibold text-slate-700">{checks.quality.metrics.focus_score}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Contrast Std</span>
                  <span className="font-semibold text-slate-700">{checks.quality.metrics.contrast_std}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Brightness</span>
                  <span className="font-semibold text-slate-700">{checks.quality.metrics.mean_brightness}</span>
                </div>
              </div>
            )}
            <p className="text-xs text-slate-500 italic">
              Status: {overall_status === 'VALID' ? 'READY for AI inference' : 'READY with warnings'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
