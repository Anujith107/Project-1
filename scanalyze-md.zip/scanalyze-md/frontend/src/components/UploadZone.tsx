import React, { useRef, useState } from 'react';
import { UploadCloud, FileText, X, AlertCircle } from 'lucide-react';
import { ModalityType } from '../types/scan';

interface UploadZoneProps {
  onFileSelect: (file: File) => void;
  selectedFile: File | null;
  previewUrl: string | null;
  onRemoveFile: () => void;
  modality: ModalityType;
  onModalityChange: (modality: ModalityType) => void;
  isUploading?: boolean;
}

export const UploadZone: React.FC<UploadZoneProps> = ({
  onFileSelect,
  selectedFile,
  previewUrl,
  onRemoveFile,
  modality,
  onModalityChange,
  isUploading = false,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const validateAndPassFile = (file: File) => {
    setErrorMessage(null);
    const validExtensions = ['.png', '.jpg', '.jpeg', '.dcm', '.dicom'];
    const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    
    if (!validExtensions.includes(ext)) {
      setErrorMessage(`Unsupported format '${ext}'. Please upload PNG, JPG, or DICOM files.`);
      return;
    }

    if (file.size > 50 * 1024 * 1024) {
      setErrorMessage('File size exceeds 50MB limit.');
      return;
    }

    onFileSelect(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      validateAndPassFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      validateAndPassFile(e.target.files[0]);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="space-y-4">
      
      {/* Modality Selector Tabs */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
        <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
          Select Modality
        </label>
        <div className="grid grid-cols-3 gap-2">
          {[
            { key: 'xray', label: 'X-Ray', desc: 'Frontal Radiograph' },
            { key: 'ct', label: 'CT', desc: 'Axial Slice' },
            { key: 'mri', label: 'MRI', desc: 'Brain MR Slice' },
          ].map((item) => {
            const isSelected = modality === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => onModalityChange(item.key as ModalityType)}
                className={`flex flex-col items-center justify-center p-2.5 rounded-lg border text-sm font-medium transition-all ${
                  isSelected
                    ? 'bg-sky-50 border-sky-600 text-sky-800 shadow-xs ring-1 ring-sky-600'
                    : 'bg-slate-50/70 border-slate-200 text-slate-600 hover:bg-slate-100 hover:border-slate-300'
                }`}
              >
                <span className="font-semibold">{item.label}</span>
                <span className="text-[11px] text-slate-500 font-normal">{item.desc}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Upload Drop Zone Card */}
      {!selectedFile ? (
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-200 bg-white ${
            isDragOver
              ? 'border-sky-500 bg-sky-50/50 shadow-md'
              : 'border-slate-300 hover:border-sky-400 hover:bg-slate-50/50 shadow-xs'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".png,.jpg,.jpeg,.dcm,.dicom"
            onChange={handleFileInputChange}
            className="hidden"
          />
          <div className="w-14 h-14 mx-auto rounded-full bg-sky-50 text-sky-600 flex items-center justify-center mb-3.5 shadow-xs">
            <UploadCloud className="w-7 h-7" />
          </div>
          <h3 className="text-base font-semibold text-slate-800 mb-1">
            Upload Medical Scan
          </h3>
          <p className="text-sm text-slate-500 mb-4">
            Drag & drop your scan file here, or{' '}
            <span className="text-sky-600 font-semibold underline underline-offset-2">Browse Files</span>
          </p>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-xs font-medium">
            <span>Supported: X-Ray • CT • MRI (DICOM, PNG, JPG)</span>
          </div>
        </div>
      ) : (
        /* Selected File Card */
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-16 h-16 rounded-lg bg-slate-900 border border-slate-200 flex-shrink-0 overflow-hidden flex items-center justify-center">
                {previewUrl ? (
                  <img
                    src={previewUrl}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <FileText className="w-8 h-8 text-slate-400" />
                )}
              </div>
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-slate-900 truncate" title={selectedFile.name}>
                  {selectedFile.name}
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  {formatFileSize(selectedFile.size)} • {modality.toUpperCase()} Modality
                </p>
                <div className="mt-1.5 flex items-center gap-2">
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                    File Loaded
                  </span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={onRemoveFile}
              disabled={isUploading}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
              title="Remove File"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Error banner */}
      {errorMessage && (
        <div className="flex items-center gap-2 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs font-medium text-rose-700">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}
    </div>
  );
};
