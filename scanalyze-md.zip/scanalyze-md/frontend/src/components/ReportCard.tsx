import React from 'react';
import { Activity, FileText, Info } from 'lucide-react';
import { ScanAnalysisResult } from '../types/scan';

interface ReportCardProps {
  data: ScanAnalysisResult;
}

export const ReportCard: React.FC<ReportCardProps> = ({ data }) => {
  const {
    modality,
    validation_status,
    anomaly_detected,
    anomaly_name,
    predicted_class_name,
    severity,
    description,
    symptoms,
    suggestions,
    patient_id,
  } = data;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'VALID':
        return (
          <span className="inline-flex items-center gap-1 font-semibold text-emerald-700">
            Valid ✓
          </span>
        );
      case 'WARNING':
        return (
          <span className="inline-flex items-center gap-1 font-semibold text-amber-700">
            Warning ⚠
          </span>
        );
      case 'INVALID':
      default:
        return (
          <span className="inline-flex items-center gap-1 font-semibold text-rose-700">
            Invalid ✕
          </span>
        );
    }
  };

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'NORMAL':
        return (
          <span className="inline-flex items-center px-3 py-0.5 rounded-md text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            NORMAL
          </span>
        );
      case 'MODERATE':
        return (
          <span className="inline-flex items-center px-3 py-0.5 rounded-md text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300">
            MODERATE
          </span>
        );
      case 'CRITICAL':
        return (
          <span className="inline-flex items-center px-3 py-0.5 rounded-md text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300 animate-pulse">
            CRITICAL
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-3 py-0.5 rounded-md text-xs font-bold bg-slate-100 text-slate-700 border border-slate-300">
            {sev || 'Not Determined'}
          </span>
        );
    }
  };

  return (
    <div className="medical-card overflow-hidden border-2 border-slate-800 shadow-md">
      
      {/* Exact Header */}
      <div className="bg-slate-900 text-white text-center py-3.5 px-6">
        <h2 className="text-sm sm:text-base font-bold tracking-widest uppercase">
          SCAN ANALYSIS
        </h2>
        {patient_id && (
          <p className="text-[11px] text-slate-400 font-mono mt-0.5">
            Patient ID: {patient_id}
          </p>
        )}
      </div>

      {/* Primary Key-Value Fields */}
      <div className="p-6 space-y-5 text-sm bg-white">
        
        <div className="space-y-2.5 pb-5 border-b border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium w-36">Modality</span>
            <span className="font-semibold text-slate-900 text-right flex-1">: {modality}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium w-36">Scan Status</span>
            <span className="font-semibold text-right flex-1">: {getStatusBadge(validation_status)}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium w-36">Anomaly</span>
            <span className="font-semibold text-slate-900 text-right flex-1">
              : {anomaly_detected ? (
                <span className="text-rose-700 font-bold">Detected ({predicted_class_name || anomaly_name})</span>
              ) : (
                <span className="text-emerald-700 font-semibold">None Detected</span>
              )}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-slate-500 font-medium w-36">Severity</span>
            <div className="text-right flex-1 flex items-center justify-end gap-1.5">
              <span className="font-semibold text-slate-900">:</span>
              {getSeverityBadge(severity)}
            </div>
          </div>
        </div>

        {/* Description Section */}
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-sky-600" />
            Description
          </h3>
          <p className="text-slate-700 text-sm leading-relaxed bg-slate-50 p-3.5 rounded-lg border border-slate-200/80">
            {description || 'No descriptive findings reported.'}
          </p>
        </div>

        {/* Common Symptoms Section */}
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-amber-600" />
            Common Symptoms
          </h3>
          <p className="text-slate-700 text-sm font-medium bg-slate-50 p-3.5 rounded-lg border border-slate-200/80">
            {symptoms || 'None specifically associated for this finding profile.'}
          </p>
          <p className="text-[11px] text-slate-400 mt-1 italic">
            *Commonly associated clinical symptoms for decision support, not patient-reported.
          </p>
        </div>

        {/* Suggestions Section */}
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-sky-600" />
            Suggestions
          </h3>
          <p className="text-slate-700 text-sm leading-relaxed bg-sky-50/50 p-3.5 rounded-lg border border-sky-200/80">
            {suggestions || 'Routine clinical correlation recommended.'}
          </p>
        </div>

      </div>
    </div>
  );
};
