import React from 'react';
import { Check, Loader2 } from 'lucide-react';

export type PipelineStep = 'upload' | 'validate' | 'preprocess' | 'analyze' | 'explain' | 'result';

interface StepperProps {
  currentStep: PipelineStep;
  isProcessing?: boolean;
}

const STEPS: { id: PipelineStep; label: string }[] = [
  { id: 'upload', label: 'Upload' },
  { id: 'validate', label: 'Validate' },
  { id: 'preprocess', label: 'Preprocess' },
  { id: 'analyze', label: 'Analyze' },
  { id: 'explain', label: 'Explain' },
  { id: 'result', label: 'Result' },
];

export const Stepper: React.FC<StepperProps> = ({ currentStep, isProcessing }) => {
  const currentIndex = STEPS.findIndex((s) => s.id === currentStep);

  return (
    <div className="w-full py-4 px-2 sm:px-6 bg-white border border-slate-200/80 rounded-xl shadow-sm mb-6">
      <div className="flex items-center justify-between relative">
        
        {/* Background Connecting Line */}
        <div className="absolute left-6 right-6 top-1/2 -translate-y-1/2 h-0.5 bg-slate-200 -z-0" />
        
        {/* Active Progress Line */}
        <div
          className="absolute left-6 top-1/2 -translate-y-1/2 h-0.5 bg-sky-600 transition-all duration-500 -z-0"
          style={{
            width: `${(Math.max(0, currentIndex) / (STEPS.length - 1)) * 100}%`,
          }}
        />

        {STEPS.map((step, idx) => {
          const isDone = idx < currentIndex;
          const isCurrent = idx === currentIndex;

          return (
            <div key={step.id} className="relative z-10 flex flex-col items-center group">
              <div
                className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center text-xs font-semibold transition-all duration-300 ${
                  isDone
                    ? 'bg-sky-600 text-white shadow-sm ring-4 ring-sky-50'
                    : isCurrent
                    ? 'bg-white border-2 border-sky-600 text-sky-700 ring-4 ring-sky-100 shadow-md'
                    : 'bg-white border-2 border-slate-300 text-slate-400'
                }`}
              >
                {isDone ? (
                  <Check className="w-4 h-4 stroke-[2.5]" />
                ) : isCurrent && isProcessing ? (
                  <Loader2 className="w-4 h-4 animate-spin text-sky-600" />
                ) : (
                  <span>{idx + 1}</span>
                )}
              </div>
              <span
                className={`mt-1.5 text-[11px] sm:text-xs font-medium tracking-tight whitespace-nowrap ${
                  isDone || isCurrent ? 'text-slate-900 font-semibold' : 'text-slate-400'
                }`}
              >
                {step.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
